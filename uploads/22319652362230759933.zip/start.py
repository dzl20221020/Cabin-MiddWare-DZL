﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2023.2.3),
    on 四月 30, 2024, at 10:54
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# Run 'Before Experiment' code from code_14
import socket
from datetime import datetime
#开始时的时间戳
timebegin = int(datetime.now().timestamp()*1000)
# 定义主机和端口
host = 'localhost'
port = 7777
# 创建一个套接字对象
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# 绑定套接字到指定的主机和端口
server_socket.connect((host, port))
#编号规则
MEclass=11
OTHERSclass=12
ANXIETYclass=13
CALMNESSclass=14
correctTask1=15
wrongTask1=16

SUICIDEclass=21
POSITIVEclass=22
NEGATIVEclass=23
NEUTRALclass=24
correctTask2=25
wrongTask2=26

stopwatchappears=31
tooearly=32
correctTask3=33
overrun=34

startOfTheParadigm=1
endOfTheParadigm=255
startClosingEyes=2
endClosingEyes=254
startOpeningEyes=3
endOpeningEyes=253



# --- Setup global variables (available in all functions) ---
# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# Store info about the experiment session
psychopyVersion = '2023.2.3'
expName = 'IAT'  # from the Builder filename that created this script
expInfo = {
    'name': '',
    'gender': '',
    'age': '',
    'participant': f"{randint(0, 999999):06.0f}",
    'date': data.getDateStr(),  # add a simple timestamp
    'expName': expName,
    'psychopyVersion': psychopyVersion,
}


def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # temporarily remove keys which the dialog doesn't need to show
    poppedKeys = {
        'date': expInfo.pop('date', data.getDateStr()),
        'expName': expInfo.pop('expName', expName),
        'psychopyVersion': expInfo.pop('psychopyVersion', psychopyVersion),
    }
    # show participant info dialog
    dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # restore hidden keys
    expInfo.update(poppedKeys)
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='D:\\psychopyFile\\Fanshi_V2.2\\IAT\\IAT_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # this outputs to the screen, not a file
    logging.console.setLevel(logging.EXP)
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log', level=logging.EXP)
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=[2560, 1440], fullscr=True, screen=0,
            winType='pyglet', allowStencil=True,
            monitor='testMonitor', color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height'
        )
        if expInfo is not None:
            # store frame rate of monitor if we can measure it
            expInfo['frameRate'] = win.getActualFrameRate()
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [-1.0000, -1.0000, -1.0000]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    win.mouseVisible = False
    win.hideMessage()
    return win


def setupInputs(expInfo, thisExp, win):
    """
    Setup whatever inputs are available (mouse, keyboard, eyetracker, etc.)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    dict
        Dictionary of input devices by name.
    """
    # --- Setup input devices ---
    inputs = {}
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    ioSession = '1'
    if 'session' in expInfo:
        ioSession = str(expInfo['session'])
    ioServer = io.launchHubServer(window=win, **ioConfig)
    eyetracker = None
    
    # create a default keyboard (e.g. to check for escape)
    defaultKeyboard = keyboard.Keyboard(backend='iohub')
    # return inputs dict
    return {
        'ioServer': ioServer,
        'defaultKeyboard': defaultKeyboard,
        'eyetracker': eyetracker,
    }

def pauseExperiment(thisExp, inputs=None, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    inputs : dict
        Dictionary of input devices by name.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # prevent components from auto-drawing
    win.stashAutoDraw()
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # make sure we have a keyboard
        if inputs is None:
            inputs = {
                'defaultKeyboard': keyboard.Keyboard(backend='ioHub')
            }
        # check for quit (typically the Esc key)
        if inputs['defaultKeyboard'].getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win, inputs=inputs)
        # flip the screen
        win.flip()
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, inputs=inputs, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # restore auto-drawn components
    win.retrieveAutoDraw()
    # reset any timers
    for timer in timers:
        timer.reset()


def run(expInfo, thisExp, win, inputs, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    inputs : dict
        Dictionary of input devices by name.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = inputs['ioServer']
    defaultKeyboard = inputs['defaultKeyboard']
    eyetracker = inputs['eyetracker']
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "Task2GetReady" ---
    text_15 = visual.TextStim(win=win, name='text_15',
        text='准备好：手指放在E、I键上',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "TextDisplay1" ---
    # Run 'Begin Experiment' code from code_14
    server_socket.sendall((expInfo['name']+" "+expInfo['gender']+" "+str(expInfo['age'])).encode('utf-8'))
    
    
    text_1 = visual.TextStim(win=win, name='text_1',
        text='按空格键开始测试',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key1 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "StartResting" ---
    text_2 = visual.TextStim(win=win, name='text_2',
        text='Press SPACE to start resting state',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key2 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Eyes" ---
    text_3 = visual.TextStim(win=win, name='text_3',
        text='please close your eyes',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "closingEyes1" ---
    text_146 = visual.TextStim(win=win, name='text_146',
        text=None,
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "Eyes1" ---
    text_4 = visual.TextStim(win=win, name='text_4',
        text='please open your eyes',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "Transition1" ---
    image_1 = visual.ImageStim(
        win=win,
        name='image_1', 
        image='tupian/hdu1.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(2, 1.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    text_5 = visual.TextStim(win=win, name='text_5',
        text='Task1',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_9 = visual.TextStim(win=win, name='text_9',
        text='任务一：内隐关联测试',
        font='Open Sans',
        pos=(0, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_148 = visual.TextStim(win=win, name='text_148',
        text='在这个任务中，你要尽可能快地按下E键或者I键，将看到的词语分组。 ',
        font='Open Sans',
        pos=(-0.31, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_149 = visual.TextStim(win=win, name='text_149',
        text='下面列出了四个类，以及属于各个类的词语：\n',
        font='Open Sans',
        pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_152 = visual.TextStim(win=win, name='text_152',
        text='            焦虑：紧张，恐惧，害怕，焦急，迷茫\n',
        font='Open Sans',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_153 = visual.TextStim(win=win, name='text_153',
        text='            冷静：放松，平衡，舒畅，安静，安宁\n',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    text_154 = visual.TextStim(win=win, name='text_154',
        text='               我：我，自己，我的，自我，本人\n',
        font='Open Sans',
        pos=(0, -0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    text_155 = visual.TextStim(win=win, name='text_155',
        text='\n             他人：他们，他们的，你的，其他人，你',
        font='Open Sans',
        pos=(0, -0.15), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-8.0);
    text_150 = visual.TextStim(win=win, name='text_150',
        text='这个任务共有7个环节，请注意，每个环节的规则都可能改变',
        font='Open Sans',
        pos=(-0.24, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-9.0);
    text_151 = visual.TextStim(win=win, name='text_151',
        text='按空格键(SPACE)开始',
        font='Open Sans',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-10.0);
    key_resp_2 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Instructions11" ---
    text_19 = visual.TextStim(win=win, name='text_19',
        text='他人',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_20 = visual.TextStim(win=win, name='text_20',
        text='我',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_21 = visual.TextStim(win=win, name='text_21',
        text='当看到属于“他人”这一类别的词语，按下E键；\n当看到属于“我”这一类别的词语，按下I键；\n词语会一个接一个出现在屏幕中间；\n\n如果你按下错误的键，屏幕中间会出现一个红色的X，\n如果你按下正确的键，屏幕中间会出现一个红色的√。\n\n在尽可能少犯错的可能下，反应速度尽可能快。\n\n按下空格键（SPACE）开始\n',
        font='Open Sans',
        pos=(-0.1, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_7 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Task11" ---
    text_22 = visual.TextStim(win=win, name='text_22',
        text='他人',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_23 = visual.TextStim(win=win, name='text_23',
        text='我',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_24 = visual.TextStim(win=win, name='text_24',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    key_resp_8 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Judge11" ---
    # Run 'Begin Experiment' code from code
    feedback = ''
    text_97 = visual.TextStim(win=win, name='text_97',
        text='',
        font='Open Sans',
        pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_60 = visual.TextStim(win=win, name='text_60',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_95 = visual.TextStim(win=win, name='text_95',
        text='他人',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_100 = visual.TextStim(win=win, name='text_100',
        text='我',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    
    # --- Initialize components for Routine "Instruction12" ---
    text_25 = visual.TextStim(win=win, name='text_25',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_26 = visual.TextStim(win=win, name='text_26',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_27 = visual.TextStim(win=win, name='text_27',
        text='当看到属于“焦虑”这一类别的词语，按下E键；\n当看到属于“冷静”这一类别的词语，按下I键；\n词语会一个接着一个出现在屏幕中间；\n\n如果你按下错误的键，屏幕中间会出现一个红色的X，\n如果你按下错误的键，屏幕中间会出现一个红色的√；\n\n在尽可能少犯错的可能下，反应速度尽可能快。\n\n按下空格键（SPACE）开始\n',
        font='Open Sans',
        pos=(-0.1, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_9 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Task12" ---
    text_61 = visual.TextStim(win=win, name='text_61',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_62 = visual.TextStim(win=win, name='text_62',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_63 = visual.TextStim(win=win, name='text_63',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    key_resp_16 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Judge12" ---
    # Run 'Begin Experiment' code from code_5
    feedback = ''
    text_101 = visual.TextStim(win=win, name='text_101',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_102 = visual.TextStim(win=win, name='text_102',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_103 = visual.TextStim(win=win, name='text_103',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_104 = visual.TextStim(win=win, name='text_104',
        text='',
        font='Open Sans',
        pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    
    # --- Initialize components for Routine "Instruction13" ---
    text_29 = visual.TextStim(win=win, name='text_29',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_30 = visual.TextStim(win=win, name='text_30',
        text='或',
        font='Open Sans',
        pos=(-0.195, 0.33), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_31 = visual.TextStim(win=win, name='text_31',
        text='他人',
        font='Open Sans',
        pos=(-0.2, 0.26), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_32 = visual.TextStim(win=win, name='text_32',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_33 = visual.TextStim(win=win, name='text_33',
        text='我',
        font='Open Sans',
        pos=(0.2, 0.26), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_34 = visual.TextStim(win=win, name='text_34',
        text='或',
        font='Open Sans',
        pos=(0.195, 0.33), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_35 = visual.TextStim(win=win, name='text_35',
        text='当看到属于“焦虑”或“他人”这两个类别的词语，按下E键；\n当看到属于“冷静”或“我”这两个类别的词语，按下I键；\n每个词语仅属于一个类别；\n\n如果你按下错误的键，屏幕中间会出现一个红色的X，\n如果你按下错误的键，屏幕中间会出现一个红色的X\n\n在尽可能少犯错的可能下，反应速度尽可能快。\n按下空格键（SPACE）开始\n',
        font='Open Sans',
        pos=(-0.1, -0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    key_resp_10 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Task13" ---
    text_64 = visual.TextStim(win=win, name='text_64',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_65 = visual.TextStim(win=win, name='text_65',
        text='或',
        font='Open Sans',
        pos=(-0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_66 = visual.TextStim(win=win, name='text_66',
        text='他人',
        font='Open Sans',
        pos=(-0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_67 = visual.TextStim(win=win, name='text_67',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_68 = visual.TextStim(win=win, name='text_68',
        text='或',
        font='Open Sans',
        pos=(0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_69 = visual.TextStim(win=win, name='text_69',
        text='我',
        font='Open Sans',
        pos=(0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    text_70 = visual.TextStim(win=win, name='text_70',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    key_resp_17 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Judge13" ---
    # Run 'Begin Experiment' code from code_6
    feedback = ''
    text_105 = visual.TextStim(win=win, name='text_105',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_106 = visual.TextStim(win=win, name='text_106',
        text='或',
        font='Open Sans',
        pos=(-0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_107 = visual.TextStim(win=win, name='text_107',
        text='他人',
        font='Open Sans',
        pos=(-0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_108 = visual.TextStim(win=win, name='text_108',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_109 = visual.TextStim(win=win, name='text_109',
        text='或',
        font='Open Sans',
        pos=(0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_110 = visual.TextStim(win=win, name='text_110',
        text='我',
        font='Open Sans',
        pos=(0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    text_111 = visual.TextStim(win=win, name='text_111',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    text_112 = visual.TextStim(win=win, name='text_112',
        text='',
        font='Open Sans',
        pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-8.0);
    
    # --- Initialize components for Routine "Instruction14" ---
    text_36 = visual.TextStim(win=win, name='text_36',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_37 = visual.TextStim(win=win, name='text_37',
        text='或',
        font='Open Sans',
        pos=(-0.195, 0.33), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_38 = visual.TextStim(win=win, name='text_38',
        text='他人',
        font='Open Sans',
        pos=(-0.2, 0.26), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_39 = visual.TextStim(win=win, name='text_39',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_40 = visual.TextStim(win=win, name='text_40',
        text='或',
        font='Open Sans',
        pos=(0.195, 0.33), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_41 = visual.TextStim(win=win, name='text_41',
        text='我',
        font='Open Sans',
        pos=(0.2, 0.26), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_42 = visual.TextStim(win=win, name='text_42',
        text='这个环节和上一个环节相同。\n当看到属于“焦虑”或“他人”这两个类别的词语，按下E键；\n当看到属于“冷静”或“我”这两个类别的词语，按下I键；\n每个词语仅属于一个类别；\n\n如果你按下错误的键，屏幕中间会出现一个红色的X，\n如果你按下错误的键，屏幕中间会出现一个红色的√；\n\n在尽可能少犯错的可能下，反应速度尽可能快。\n\n按下空格键（SPACE）开始\n',
        font='Open Sans',
        pos=(-0.1, -0.145), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    key_resp_11 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Task14" ---
    text_71 = visual.TextStim(win=win, name='text_71',
        text='焦急',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_72 = visual.TextStim(win=win, name='text_72',
        text='或',
        font='Open Sans',
        pos=(-0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_73 = visual.TextStim(win=win, name='text_73',
        text='他人',
        font='Open Sans',
        pos=(-0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_74 = visual.TextStim(win=win, name='text_74',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_75 = visual.TextStim(win=win, name='text_75',
        text='或',
        font='Open Sans',
        pos=(0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_76 = visual.TextStim(win=win, name='text_76',
        text='我',
        font='Open Sans',
        pos=(0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    text_77 = visual.TextStim(win=win, name='text_77',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    key_resp_21 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Judge14" ---
    # Run 'Begin Experiment' code from code_7
    feedback = ''
    text_113 = visual.TextStim(win=win, name='text_113',
        text='焦急',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_114 = visual.TextStim(win=win, name='text_114',
        text='或',
        font='Open Sans',
        pos=(-0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_115 = visual.TextStim(win=win, name='text_115',
        text='他人',
        font='Open Sans',
        pos=(-0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_116 = visual.TextStim(win=win, name='text_116',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_117 = visual.TextStim(win=win, name='text_117',
        text='或',
        font='Open Sans',
        pos=(0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_118 = visual.TextStim(win=win, name='text_118',
        text='我',
        font='Open Sans',
        pos=(0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    text_119 = visual.TextStim(win=win, name='text_119',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    text_120 = visual.TextStim(win=win, name='text_120',
        text='',
        font='Open Sans',
        pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-8.0);
    
    # --- Initialize components for Routine "Instruction15" ---
    text_43 = visual.TextStim(win=win, name='text_43',
        text='我',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_44 = visual.TextStim(win=win, name='text_44',
        text='他人',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_45 = visual.TextStim(win=win, name='text_45',
        text='请注意，规则改变了（和之前相反）！\n\n当看到属于“我”这一类别的词语，按下E键；\n当看到属于“他人”这一类别的词语，按下I键；\n\n如果你按下错误的键，屏幕中间会出现一个红色的X，\n如果你按下错误的键，屏幕中间会出现一个红色的√；\n\n在尽可能少犯错的可能下，反应速度尽可能快。\n\n按下空格键（SPACE）开始\n',
        font='Open Sans',
        pos=(-0.1, -0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_12 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Task15" ---
    text_78 = visual.TextStim(win=win, name='text_78',
        text='我',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_79 = visual.TextStim(win=win, name='text_79',
        text='他人',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_80 = visual.TextStim(win=win, name='text_80',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    key_resp_18 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Judge15" ---
    # Run 'Begin Experiment' code from code_8
    feedback = ''
    text_121 = visual.TextStim(win=win, name='text_121',
        text='我',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_122 = visual.TextStim(win=win, name='text_122',
        text='他人',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_123 = visual.TextStim(win=win, name='text_123',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_124 = visual.TextStim(win=win, name='text_124',
        text='',
        font='Open Sans',
        pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    
    # --- Initialize components for Routine "Instruction16" ---
    text_46 = visual.TextStim(win=win, name='text_46',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_47 = visual.TextStim(win=win, name='text_47',
        text='或',
        font='Open Sans',
        pos=(-0.195, 0.33), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_48 = visual.TextStim(win=win, name='text_48',
        text='我',
        font='Open Sans',
        pos=(-0.2, 0.26), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_49 = visual.TextStim(win=win, name='text_49',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_50 = visual.TextStim(win=win, name='text_50',
        text='或',
        font='Open Sans',
        pos=(0.195, 0.33), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_51 = visual.TextStim(win=win, name='text_51',
        text='他人',
        font='Open Sans',
        pos=(0.2, 0.26), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_59 = visual.TextStim(win=win, name='text_59',
        text='当看到属于“焦虑”或“我”这两个类别的词语，按下E键；\n当看到属于“冷静”或“他人”这两个类别的词语，按下I键；\n\n每个词语仅属于一个类别；\n\n如果你按下错误的键，屏幕中间会出现一个红色的X，\n如果你按下错误的键，屏幕中间会出现一个红色的√；\n\n在尽可能少犯错的可能下，反应速度尽可能快。\n\n按下空格键（SPACE）开始\n',
        font='Open Sans',
        pos=(-0.1, -0.145), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    key_resp_13 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Task16" ---
    text_81 = visual.TextStim(win=win, name='text_81',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_82 = visual.TextStim(win=win, name='text_82',
        text='或',
        font='Open Sans',
        pos=(-0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_83 = visual.TextStim(win=win, name='text_83',
        text='我',
        font='Open Sans',
        pos=(-0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_84 = visual.TextStim(win=win, name='text_84',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_85 = visual.TextStim(win=win, name='text_85',
        text='或',
        font='Open Sans',
        pos=(0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_86 = visual.TextStim(win=win, name='text_86',
        text='他人',
        font='Open Sans',
        pos=(0.2,0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    text_87 = visual.TextStim(win=win, name='text_87',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    key_resp_19 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Judge16" ---
    # Run 'Begin Experiment' code from code_9
    feedback = ''
    text_125 = visual.TextStim(win=win, name='text_125',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_126 = visual.TextStim(win=win, name='text_126',
        text='或',
        font='Open Sans',
        pos=(-0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_127 = visual.TextStim(win=win, name='text_127',
        text='我',
        font='Open Sans',
        pos=(-0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_128 = visual.TextStim(win=win, name='text_128',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_129 = visual.TextStim(win=win, name='text_129',
        text='或',
        font='Open Sans',
        pos=(0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_130 = visual.TextStim(win=win, name='text_130',
        text='他人',
        font='Open Sans',
        pos=(0.2,0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    text_131 = visual.TextStim(win=win, name='text_131',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    text_132 = visual.TextStim(win=win, name='text_132',
        text='',
        font='Open Sans',
        pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-8.0);
    
    # --- Initialize components for Routine "Instruction17" ---
    text_52 = visual.TextStim(win=win, name='text_52',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_53 = visual.TextStim(win=win, name='text_53',
        text='或',
        font='Open Sans',
        pos=(-0.195, 0.33), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_54 = visual.TextStim(win=win, name='text_54',
        text='我',
        font='Open Sans',
        pos=(-0.2, 0.26), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_55 = visual.TextStim(win=win, name='text_55',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_56 = visual.TextStim(win=win, name='text_56',
        text='或',
        font='Open Sans',
        pos=(0.195, 0.33), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_57 = visual.TextStim(win=win, name='text_57',
        text='他人',
        font='Open Sans',
        pos=(0.2, 0.26), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_58 = visual.TextStim(win=win, name='text_58',
        text='这个环节和上一个环节相同。\n\n当看到属于“焦虑”或“我”这两个类别的词语，按下E键；\n当看到属于“冷静”或“他人”这两个类别的词语，按下I键；\n每个词语仅属于一个类别；\n\n如果你按下错误的键，屏幕中间会出现一个红色的X，\n如果你按下错误的键，屏幕中间会出现一个红色的√；\n\n在尽可能少犯错的可能下，反应速度尽可能快。\n\n按下空格键（SPACE）开始\n',
        font='Open Sans',
        pos=(-0.1, -0.145), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    key_resp_14 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Task17" ---
    text_88 = visual.TextStim(win=win, name='text_88',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_89 = visual.TextStim(win=win, name='text_89',
        text='或',
        font='Open Sans',
        pos=(-0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_90 = visual.TextStim(win=win, name='text_90',
        text='我',
        font='Open Sans',
        pos=(-0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_91 = visual.TextStim(win=win, name='text_91',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_92 = visual.TextStim(win=win, name='text_92',
        text='或',
        font='Open Sans',
        pos=(0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_93 = visual.TextStim(win=win, name='text_93',
        text='他人',
        font='Open Sans',
        pos=(0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    text_94 = visual.TextStim(win=win, name='text_94',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    key_resp_20 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Judge17" ---
    # Run 'Begin Experiment' code from code_10
    feedback = ''
    text_133 = visual.TextStim(win=win, name='text_133',
        text='焦虑',
        font='Open Sans',
        pos=(-0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_134 = visual.TextStim(win=win, name='text_134',
        text='或',
        font='Open Sans',
        pos=(-0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_135 = visual.TextStim(win=win, name='text_135',
        text='我',
        font='Open Sans',
        pos=(-0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_136 = visual.TextStim(win=win, name='text_136',
        text='冷静',
        font='Open Sans',
        pos=(0.2, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, 0.0039, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    text_137 = visual.TextStim(win=win, name='text_137',
        text='或',
        font='Open Sans',
        pos=(0.2, 0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    text_138 = visual.TextStim(win=win, name='text_138',
        text='他人',
        font='Open Sans',
        pos=(0.2, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, 1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    text_139 = visual.TextStim(win=win, name='text_139',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    text_140 = visual.TextStim(win=win, name='text_140',
        text='',
        font='Open Sans',
        pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-8.0);
    
    # --- Initialize components for Routine "Task1Over" ---
    text1 = visual.TextStim(win=win, name='text1',
        text='恭喜你！任务一结束！\n\n    (按空格继续)',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_ = keyboard.Keyboard()
    
    # --- Initialize components for Routine "OpeningEyes" ---
    text = visual.TextStim(win=win, name='text',
        text='please keep opening your eyes',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "openingEyes1" ---
    text_147 = visual.TextStim(win=win, name='text_147',
        text='+',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "Transition2" ---
    image = visual.ImageStim(
        win=win,
        name='image', 
        image='tupian/hdu4.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(2, 1.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    text_7 = visual.TextStim(win=win, name='text_7',
        text='Task2',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_8 = visual.TextStim(win=win, name='text_8',
        text='任务二：斯特鲁普测验\n在这个任务中，你会看见各种不同颜色的词语，\n你需要识别每个词语的颜色：\n- 看到蓝色的词语，按下E键\n\n- 看到红色的词语，按下I键\n\n\n例如：如果你看见字  \n因为它是红色的，请按下I键；\n\n由于限时，所以尽你可能做到快且精准。\n如果你出错了，屏幕上不会有任何提示\n按空格键(SPACE)开始\n',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp = keyboard.Keyboard()
    text_28 = visual.TextStim(win=win, name='text_28',
        text='死亡',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    
    # --- Initialize components for Routine "Task2GetReady" ---
    text_15 = visual.TextStim(win=win, name='text_15',
        text='准备好：手指放在E、I键上',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "Task2" ---
    text_16 = visual.TextStim(win=win, name='text_16',
        text='I：蓝色',
        font='Open Sans',
        pos=(0.2, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_17 = visual.TextStim(win=win, name='text_17',
        text='E：红色',
        font='Open Sans',
        pos=(-0.2, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_18 = visual.TextStim(win=win, name='text_18',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    key_resp_6 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Judge18" ---
    # Run 'Begin Experiment' code from code_11
    feedback = ''
    text_141 = visual.TextStim(win=win, name='text_141',
        text='I：蓝色',
        font='Open Sans',
        pos=(0.2, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_142 = visual.TextStim(win=win, name='text_142',
        text='E：红色',
        font='Open Sans',
        pos=(-0.2, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_143 = visual.TextStim(win=win, name='text_143',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_144 = visual.TextStim(win=win, name='text_144',
        text='',
        font='Open Sans',
        pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    
    # --- Initialize components for Routine "Task2Over" ---
    text_6 = visual.TextStim(win=win, name='text_6',
        text='任务二结束！\n\n(按空格继续)',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_3 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Transition3" ---
    image_2 = visual.ImageStim(
        win=win,
        name='image_2', 
        image='tupian/hdu3.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(2, 1.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    text_10 = visual.TextStim(win=win, name='text_10',
        text='Task3',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color=[1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_11 = visual.TextStim(win=win, name='text_11',
        text='任务三：心理警觉性测试\n这是一个简单的快速反应任务；\n\n\n当红色秒表\n\n出现在屏幕中间时，迅速按下空格键；\n屏幕会显示你的反应时间；\n\n这个测试有10分钟\n\n\n按下空格键（Space）开始\n',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_4 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "Task3GetReady" ---
    text_12 = visual.TextStim(win=win, name='text_12',
        text='                准备好：\n手指放在空格键（Space）上',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_13 = visual.TextStim(win=win, name='text_13',
        text='别忘了，红色秒表出现的时候快速按下空格键',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "zhushidian" ---
    # Run 'Begin Experiment' code from code_4
    import random
    time = 0
    text_99 = visual.TextStim(win=win, name='text_99',
        text='+',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_15 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "TooEarly" ---
    text_145 = visual.TextStim(win=win, name='text_145',
        text='按键太早了！',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "Task3" ---
    image_3 = visual.ImageStim(
        win=win,
        name='image_3', 
        image='tupian/red.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.6, 0.2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    show_time = visual.TextStim(win=win, name='show_time',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_22 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "xianshi" ---
    # Run 'Begin Experiment' code from code_2
    feedback = ''
    text_96 = visual.TextStim(win=win, name='text_96',
        text='',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "Goodbye" ---
    text_14 = visual.TextStim(win=win, name='text_14',
        text='感谢您的参与\n\n(按空格退出)',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_5 = keyboard.Keyboard()
    
    # create some handy timers
    if globalClock is None:
        globalClock = core.Clock()  # to track the time since experiment started
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6)
    
    # --- Prepare to start Routine "Task2GetReady" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Task2GetReady.started', globalClock.getTime())
    # keep track of which components have finished
    Task2GetReadyComponents = [text_15]
    for thisComponent in Task2GetReadyComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Task2GetReady" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 2.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_15* updates
        
        # if text_15 is starting this frame...
        if text_15.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_15.frameNStart = frameN  # exact frame index
            text_15.tStart = t  # local t and not account for scr refresh
            text_15.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_15, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_15.started')
            # update status
            text_15.status = STARTED
            text_15.setAutoDraw(True)
        
        # if text_15 is active this frame...
        if text_15.status == STARTED:
            # update params
            pass
        
        # if text_15 is stopping this frame...
        if text_15.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_15.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text_15.tStop = t  # not accounting for scr refresh
                text_15.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_15.stopped')
                # update status
                text_15.status = FINISHED
                text_15.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Task2GetReadyComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Task2GetReady" ---
    for thisComponent in Task2GetReadyComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Task2GetReady.stopped', globalClock.getTime())
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-2.000000)
    
    # --- Prepare to start Routine "TextDisplay1" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('TextDisplay1.started', globalClock.getTime())
    key1.keys = []
    key1.rt = []
    _key1_allKeys = []
    # keep track of which components have finished
    TextDisplay1Components = [text_1, key1]
    for thisComponent in TextDisplay1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "TextDisplay1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_1* updates
        
        # if text_1 is starting this frame...
        if text_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_1.frameNStart = frameN  # exact frame index
            text_1.tStart = t  # local t and not account for scr refresh
            text_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_1.started')
            # update status
            text_1.status = STARTED
            text_1.setAutoDraw(True)
        
        # if text_1 is active this frame...
        if text_1.status == STARTED:
            # update params
            pass
        
        # *key1* updates
        waitOnFlip = False
        
        # if key1 is starting this frame...
        if key1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key1.frameNStart = frameN  # exact frame index
            key1.tStart = t  # local t and not account for scr refresh
            key1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key1.started')
            # update status
            key1.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key1.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key1.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key1.status == STARTED and not waitOnFlip:
            theseKeys = key1.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key1_allKeys.extend(theseKeys)
            if len(_key1_allKeys):
                key1.keys = _key1_allKeys[-1].name  # just the last key pressed
                key1.rt = _key1_allKeys[-1].rt
                key1.duration = _key1_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in TextDisplay1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "TextDisplay1" ---
    for thisComponent in TextDisplay1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('TextDisplay1.stopped', globalClock.getTime())
    # check responses
    if key1.keys in ['', [], None]:  # No response was made
        key1.keys = None
    thisExp.addData('key1.keys',key1.keys)
    if key1.keys != None:  # we had a response
        thisExp.addData('key1.rt', key1.rt)
        thisExp.addData('key1.duration', key1.duration)
    thisExp.nextEntry()
    # the Routine "TextDisplay1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "StartResting" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('StartResting.started', globalClock.getTime())
    # Run 'Begin Routine' code from code_24
    datastamp=int(datetime.now().timestamp()*1000)-timebegin
    server_socket.sendall((str(startOfTheParadigm)).encode('utf-8') + b'\n')

    key2.keys = []
    key2.rt = []
    _key2_allKeys = []
    # keep track of which components have finished
    StartRestingComponents = [text_2, key2]
    for thisComponent in StartRestingComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "StartResting" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_2* updates
        
        # if text_2 is starting this frame...
        if text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_2.frameNStart = frameN  # exact frame index
            text_2.tStart = t  # local t and not account for scr refresh
            text_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_2.started')
            # update status
            text_2.status = STARTED
            text_2.setAutoDraw(True)
        
        # if text_2 is active this frame...
        if text_2.status == STARTED:
            # update params
            pass
        
        # *key2* updates
        waitOnFlip = False
        
        # if key2 is starting this frame...
        if key2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key2.frameNStart = frameN  # exact frame index
            key2.tStart = t  # local t and not account for scr refresh
            key2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key2.started')
            # update status
            key2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key2.status == STARTED and not waitOnFlip:
            theseKeys = key2.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key2_allKeys.extend(theseKeys)
            if len(_key2_allKeys):
                key2.keys = _key2_allKeys[-1].name  # just the last key pressed
                key2.rt = _key2_allKeys[-1].rt
                key2.duration = _key2_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in StartRestingComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "StartResting" ---
    for thisComponent in StartRestingComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('StartResting.stopped', globalClock.getTime())
    # check responses
    if key2.keys in ['', [], None]:  # No response was made
        key2.keys = None
    thisExp.addData('key2.keys',key2.keys)
    if key2.keys != None:  # we had a response
        thisExp.addData('key2.rt', key2.rt)
        thisExp.addData('key2.duration', key2.duration)
    thisExp.nextEntry()
    # the Routine "StartResting" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Eyes" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Eyes.started', globalClock.getTime())
    # keep track of which components have finished
    EyesComponents = [text_3]
    for thisComponent in EyesComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Eyes" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 2.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_3* updates
        
        # if text_3 is starting this frame...
        if text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_3.frameNStart = frameN  # exact frame index
            text_3.tStart = t  # local t and not account for scr refresh
            text_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_3.started')
            # update status
            text_3.status = STARTED
            text_3.setAutoDraw(True)
        
        # if text_3 is active this frame...
        if text_3.status == STARTED:
            # update params
            pass
        
        # if text_3 is stopping this frame...
        if text_3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_3.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text_3.tStop = t  # not accounting for scr refresh
                text_3.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_3.stopped')
                # update status
                text_3.status = FINISHED
                text_3.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in EyesComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Eyes" ---
    for thisComponent in EyesComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Eyes.stopped', globalClock.getTime())
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-2.000000)
    
    # --- Prepare to start Routine "closingEyes1" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('closingEyes1.started', globalClock.getTime())
    # Run 'Begin Routine' code from code_25
    datastamp=int(datetime.now().timestamp()*1000)-timebegin
    server_socket.sendall((str(startClosingEyes)).encode('utf-8')+ b'\n')
    # keep track of which components have finished
    closingEyes1Components = [text_146]
    for thisComponent in closingEyes1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "closingEyes1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 60.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_146* updates
        
        # if text_146 is starting this frame...
        if text_146.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_146.frameNStart = frameN  # exact frame index
            text_146.tStart = t  # local t and not account for scr refresh
            text_146.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_146, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_146.started')
            # update status
            text_146.status = STARTED
            text_146.setAutoDraw(True)
        
        # if text_146 is active this frame...
        if text_146.status == STARTED:
            # update params
            pass
        
        # if text_146 is stopping this frame...
        if text_146.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_146.tStartRefresh + 60-frameTolerance:
                # keep track of stop time/frame for later
                text_146.tStop = t  # not accounting for scr refresh
                text_146.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_146.stopped')
                # update status
                text_146.status = FINISHED
                text_146.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in closingEyes1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "closingEyes1" ---
    for thisComponent in closingEyes1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('closingEyes1.stopped', globalClock.getTime())
    # Run 'End Routine' code from code_25
    server_socket.sendall((str(endClosingEyes)).encode('utf-8')+ b'\n')
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-60.000000)
    
    # --- Prepare to start Routine "Eyes1" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Eyes1.started', globalClock.getTime())
    # keep track of which components have finished
    Eyes1Components = [text_4]
    for thisComponent in Eyes1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Eyes1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 2.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_4* updates
        
        # if text_4 is starting this frame...
        if text_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_4.frameNStart = frameN  # exact frame index
            text_4.tStart = t  # local t and not account for scr refresh
            text_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_4.started')
            # update status
            text_4.status = STARTED
            text_4.setAutoDraw(True)
        
        # if text_4 is active this frame...
        if text_4.status == STARTED:
            # update params
            pass
        
        # if text_4 is stopping this frame...
        if text_4.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_4.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text_4.tStop = t  # not accounting for scr refresh
                text_4.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_4.stopped')
                # update status
                text_4.status = FINISHED
                text_4.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Eyes1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Eyes1" ---
    for thisComponent in Eyes1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Eyes1.stopped', globalClock.getTime())
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-2.000000)
    
    # --- Prepare to start Routine "Transition1" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Transition1.started', globalClock.getTime())
    key_resp_2.keys = []
    key_resp_2.rt = []
    _key_resp_2_allKeys = []
    # keep track of which components have finished
    Transition1Components = [image_1, text_5, text_9, text_148, text_149, text_152, text_153, text_154, text_155, text_150, text_151, key_resp_2]
    for thisComponent in Transition1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Transition1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image_1* updates
        
        # if image_1 is starting this frame...
        if image_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_1.frameNStart = frameN  # exact frame index
            image_1.tStart = t  # local t and not account for scr refresh
            image_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_1.started')
            # update status
            image_1.status = STARTED
            image_1.setAutoDraw(True)
        
        # if image_1 is active this frame...
        if image_1.status == STARTED:
            # update params
            pass
        
        # if image_1 is stopping this frame...
        if image_1.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > image_1.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                image_1.tStop = t  # not accounting for scr refresh
                image_1.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_1.stopped')
                # update status
                image_1.status = FINISHED
                image_1.setAutoDraw(False)
        
        # *text_5* updates
        
        # if text_5 is starting this frame...
        if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_5.frameNStart = frameN  # exact frame index
            text_5.tStart = t  # local t and not account for scr refresh
            text_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_5.started')
            # update status
            text_5.status = STARTED
            text_5.setAutoDraw(True)
        
        # if text_5 is active this frame...
        if text_5.status == STARTED:
            # update params
            pass
        
        # if text_5 is stopping this frame...
        if text_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_5.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text_5.tStop = t  # not accounting for scr refresh
                text_5.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_5.stopped')
                # update status
                text_5.status = FINISHED
                text_5.setAutoDraw(False)
        
        # *text_9* updates
        
        # if text_9 is starting this frame...
        if text_9.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_9.frameNStart = frameN  # exact frame index
            text_9.tStart = t  # local t and not account for scr refresh
            text_9.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_9, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_9.started')
            # update status
            text_9.status = STARTED
            text_9.setAutoDraw(True)
        
        # if text_9 is active this frame...
        if text_9.status == STARTED:
            # update params
            pass
        
        # *text_148* updates
        
        # if text_148 is starting this frame...
        if text_148.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_148.frameNStart = frameN  # exact frame index
            text_148.tStart = t  # local t and not account for scr refresh
            text_148.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_148, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_148.started')
            # update status
            text_148.status = STARTED
            text_148.setAutoDraw(True)
        
        # if text_148 is active this frame...
        if text_148.status == STARTED:
            # update params
            pass
        
        # *text_149* updates
        
        # if text_149 is starting this frame...
        if text_149.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_149.frameNStart = frameN  # exact frame index
            text_149.tStart = t  # local t and not account for scr refresh
            text_149.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_149, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_149.started')
            # update status
            text_149.status = STARTED
            text_149.setAutoDraw(True)
        
        # if text_149 is active this frame...
        if text_149.status == STARTED:
            # update params
            pass
        
        # *text_152* updates
        
        # if text_152 is starting this frame...
        if text_152.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_152.frameNStart = frameN  # exact frame index
            text_152.tStart = t  # local t and not account for scr refresh
            text_152.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_152, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_152.started')
            # update status
            text_152.status = STARTED
            text_152.setAutoDraw(True)
        
        # if text_152 is active this frame...
        if text_152.status == STARTED:
            # update params
            pass
        
        # *text_153* updates
        
        # if text_153 is starting this frame...
        if text_153.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_153.frameNStart = frameN  # exact frame index
            text_153.tStart = t  # local t and not account for scr refresh
            text_153.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_153, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_153.started')
            # update status
            text_153.status = STARTED
            text_153.setAutoDraw(True)
        
        # if text_153 is active this frame...
        if text_153.status == STARTED:
            # update params
            pass
        
        # *text_154* updates
        
        # if text_154 is starting this frame...
        if text_154.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_154.frameNStart = frameN  # exact frame index
            text_154.tStart = t  # local t and not account for scr refresh
            text_154.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_154, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_154.started')
            # update status
            text_154.status = STARTED
            text_154.setAutoDraw(True)
        
        # if text_154 is active this frame...
        if text_154.status == STARTED:
            # update params
            pass
        
        # *text_155* updates
        
        # if text_155 is starting this frame...
        if text_155.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_155.frameNStart = frameN  # exact frame index
            text_155.tStart = t  # local t and not account for scr refresh
            text_155.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_155, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_155.started')
            # update status
            text_155.status = STARTED
            text_155.setAutoDraw(True)
        
        # if text_155 is active this frame...
        if text_155.status == STARTED:
            # update params
            pass
        
        # *text_150* updates
        
        # if text_150 is starting this frame...
        if text_150.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_150.frameNStart = frameN  # exact frame index
            text_150.tStart = t  # local t and not account for scr refresh
            text_150.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_150, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_150.started')
            # update status
            text_150.status = STARTED
            text_150.setAutoDraw(True)
        
        # if text_150 is active this frame...
        if text_150.status == STARTED:
            # update params
            pass
        
        # *text_151* updates
        
        # if text_151 is starting this frame...
        if text_151.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_151.frameNStart = frameN  # exact frame index
            text_151.tStart = t  # local t and not account for scr refresh
            text_151.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_151, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_151.started')
            # update status
            text_151.status = STARTED
            text_151.setAutoDraw(True)
        
        # if text_151 is active this frame...
        if text_151.status == STARTED:
            # update params
            pass
        
        # *key_resp_2* updates
        waitOnFlip = False
        
        # if key_resp_2 is starting this frame...
        if key_resp_2.status == NOT_STARTED and tThisFlip >= 2.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_2.frameNStart = frameN  # exact frame index
            key_resp_2.tStart = t  # local t and not account for scr refresh
            key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_2.started')
            # update status
            key_resp_2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_2.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_2.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_2_allKeys.extend(theseKeys)
            if len(_key_resp_2_allKeys):
                key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
                key_resp_2.rt = _key_resp_2_allKeys[-1].rt
                key_resp_2.duration = _key_resp_2_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Transition1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Transition1" ---
    for thisComponent in Transition1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Transition1.stopped', globalClock.getTime())
    # check responses
    if key_resp_2.keys in ['', [], None]:  # No response was made
        key_resp_2.keys = None
    thisExp.addData('key_resp_2.keys',key_resp_2.keys)
    if key_resp_2.keys != None:  # we had a response
        thisExp.addData('key_resp_2.rt', key_resp_2.rt)
        thisExp.addData('key_resp_2.duration', key_resp_2.duration)
    thisExp.nextEntry()
    # the Routine "Transition1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Instructions11" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Instructions11.started', globalClock.getTime())
    key_resp_7.keys = []
    key_resp_7.rt = []
    _key_resp_7_allKeys = []
    # keep track of which components have finished
    Instructions11Components = [text_19, text_20, text_21, key_resp_7]
    for thisComponent in Instructions11Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instructions11" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_19* updates
        
        # if text_19 is starting this frame...
        if text_19.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_19.frameNStart = frameN  # exact frame index
            text_19.tStart = t  # local t and not account for scr refresh
            text_19.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_19, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_19.started')
            # update status
            text_19.status = STARTED
            text_19.setAutoDraw(True)
        
        # if text_19 is active this frame...
        if text_19.status == STARTED:
            # update params
            pass
        
        # *text_20* updates
        
        # if text_20 is starting this frame...
        if text_20.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_20.frameNStart = frameN  # exact frame index
            text_20.tStart = t  # local t and not account for scr refresh
            text_20.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_20, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_20.started')
            # update status
            text_20.status = STARTED
            text_20.setAutoDraw(True)
        
        # if text_20 is active this frame...
        if text_20.status == STARTED:
            # update params
            pass
        
        # *text_21* updates
        
        # if text_21 is starting this frame...
        if text_21.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_21.frameNStart = frameN  # exact frame index
            text_21.tStart = t  # local t and not account for scr refresh
            text_21.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_21, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_21.started')
            # update status
            text_21.status = STARTED
            text_21.setAutoDraw(True)
        
        # if text_21 is active this frame...
        if text_21.status == STARTED:
            # update params
            pass
        
        # *key_resp_7* updates
        waitOnFlip = False
        
        # if key_resp_7 is starting this frame...
        if key_resp_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_7.frameNStart = frameN  # exact frame index
            key_resp_7.tStart = t  # local t and not account for scr refresh
            key_resp_7.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_7, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_7.started')
            # update status
            key_resp_7.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_7.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_7.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_7.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_7.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_7_allKeys.extend(theseKeys)
            if len(_key_resp_7_allKeys):
                key_resp_7.keys = _key_resp_7_allKeys[-1].name  # just the last key pressed
                key_resp_7.rt = _key_resp_7_allKeys[-1].rt
                key_resp_7.duration = _key_resp_7_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Instructions11Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instructions11" ---
    for thisComponent in Instructions11Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Instructions11.stopped', globalClock.getTime())
    # check responses
    if key_resp_7.keys in ['', [], None]:  # No response was made
        key_resp_7.keys = None
    thisExp.addData('key_resp_7.keys',key_resp_7.keys)
    if key_resp_7.keys != None:  # we had a response
        thisExp.addData('key_resp_7.rt', key_resp_7.rt)
        thisExp.addData('key_resp_7.duration', key_resp_7.duration)
    thisExp.nextEntry()
    # the Routine "Instructions11" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_2 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Task11.xlsx'),
        seed=None, name='trials_2')
    thisExp.addLoop(trials_2)  # add the loop to the experiment
    thisTrial_2 = trials_2.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
    if thisTrial_2 != None:
        for paramName in thisTrial_2:
            globals()[paramName] = thisTrial_2[paramName]
    
    for thisTrial_2 in trials_2:
        currentLoop = trials_2
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
        if thisTrial_2 != None:
            for paramName in thisTrial_2:
                globals()[paramName] = thisTrial_2[paramName]
        
        # --- Prepare to start Routine "Task11" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Task11.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_15
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        server_socket.sendall((str(MarkNumber)).encode('utf-8')+ b'\n')
        
        text_24.setText(word)
        key_resp_8.keys = []
        key_resp_8.rt = []
        _key_resp_8_allKeys = []
        # keep track of which components have finished
        Task11Components = [text_22, text_23, text_24, key_resp_8]
        for thisComponent in Task11Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Task11" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_22* updates
            
            # if text_22 is starting this frame...
            if text_22.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_22.frameNStart = frameN  # exact frame index
                text_22.tStart = t  # local t and not account for scr refresh
                text_22.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_22, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_22.started')
                # update status
                text_22.status = STARTED
                text_22.setAutoDraw(True)
            
            # if text_22 is active this frame...
            if text_22.status == STARTED:
                # update params
                pass
            
            # *text_23* updates
            
            # if text_23 is starting this frame...
            if text_23.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_23.frameNStart = frameN  # exact frame index
                text_23.tStart = t  # local t and not account for scr refresh
                text_23.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_23, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_23.started')
                # update status
                text_23.status = STARTED
                text_23.setAutoDraw(True)
            
            # if text_23 is active this frame...
            if text_23.status == STARTED:
                # update params
                pass
            
            # *text_24* updates
            
            # if text_24 is starting this frame...
            if text_24.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_24.frameNStart = frameN  # exact frame index
                text_24.tStart = t  # local t and not account for scr refresh
                text_24.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_24, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_24.started')
                # update status
                text_24.status = STARTED
                text_24.setAutoDraw(True)
            
            # if text_24 is active this frame...
            if text_24.status == STARTED:
                # update params
                pass
            
            # *key_resp_8* updates
            waitOnFlip = False
            
            # if key_resp_8 is starting this frame...
            if key_resp_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_8.frameNStart = frameN  # exact frame index
                key_resp_8.tStart = t  # local t and not account for scr refresh
                key_resp_8.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_8, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_8.started')
                # update status
                key_resp_8.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_8.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_8.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_8.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_8.getKeys(keyList=['e','i'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_8_allKeys.extend(theseKeys)
                if len(_key_resp_8_allKeys):
                    key_resp_8.keys = _key_resp_8_allKeys[0].name  # just the first key pressed
                    key_resp_8.rt = _key_resp_8_allKeys[0].rt
                    key_resp_8.duration = _key_resp_8_allKeys[0].duration
                    # was this correct?
                    if (key_resp_8.keys == str(answer)) or (key_resp_8.keys == answer):
                        key_resp_8.corr = 1
                    else:
                        key_resp_8.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Task11Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Task11" ---
        for thisComponent in Task11Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Task11.stopped', globalClock.getTime())
        # check responses
        if key_resp_8.keys in ['', [], None]:  # No response was made
            key_resp_8.keys = None
            # was no response the correct answer?!
            if str(answer).lower() == 'none':
               key_resp_8.corr = 1;  # correct non-response
            else:
               key_resp_8.corr = 0;  # failed to respond (incorrectly)
        # store data for trials_2 (TrialHandler)
        trials_2.addData('key_resp_8.keys',key_resp_8.keys)
        trials_2.addData('key_resp_8.corr', key_resp_8.corr)
        if key_resp_8.keys != None:  # we had a response
            trials_2.addData('key_resp_8.rt', key_resp_8.rt)
            trials_2.addData('key_resp_8.duration', key_resp_8.duration)
        # the Routine "Task11" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Judge11" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Judge11.started', globalClock.getTime())
        # Run 'Begin Routine' code from code
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        if key_resp_8.corr==1:
            feedback = '√'
            server_socket.sendall((str(correctTask1)).encode('utf-8')+ b'\n')
        else:
            feedback = '×'
            server_socket.sendall((str(wrongTask1)).encode('utf-8')+ b'\n')
        
        
        
        text_97.setText(feedback)
        text_60.setText(word)
        # keep track of which components have finished
        Judge11Components = [text_97, text_60, text_95, text_100]
        for thisComponent in Judge11Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Judge11" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_97* updates
            
            # if text_97 is starting this frame...
            if text_97.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_97.frameNStart = frameN  # exact frame index
                text_97.tStart = t  # local t and not account for scr refresh
                text_97.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_97, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_97.started')
                # update status
                text_97.status = STARTED
                text_97.setAutoDraw(True)
            
            # if text_97 is active this frame...
            if text_97.status == STARTED:
                # update params
                pass
            
            # if text_97 is stopping this frame...
            if text_97.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_97.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_97.tStop = t  # not accounting for scr refresh
                    text_97.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_97.stopped')
                    # update status
                    text_97.status = FINISHED
                    text_97.setAutoDraw(False)
            
            # *text_60* updates
            
            # if text_60 is starting this frame...
            if text_60.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_60.frameNStart = frameN  # exact frame index
                text_60.tStart = t  # local t and not account for scr refresh
                text_60.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_60, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_60.started')
                # update status
                text_60.status = STARTED
                text_60.setAutoDraw(True)
            
            # if text_60 is active this frame...
            if text_60.status == STARTED:
                # update params
                pass
            
            # if text_60 is stopping this frame...
            if text_60.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_60.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_60.tStop = t  # not accounting for scr refresh
                    text_60.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_60.stopped')
                    # update status
                    text_60.status = FINISHED
                    text_60.setAutoDraw(False)
            
            # *text_95* updates
            
            # if text_95 is starting this frame...
            if text_95.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_95.frameNStart = frameN  # exact frame index
                text_95.tStart = t  # local t and not account for scr refresh
                text_95.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_95, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_95.started')
                # update status
                text_95.status = STARTED
                text_95.setAutoDraw(True)
            
            # if text_95 is active this frame...
            if text_95.status == STARTED:
                # update params
                pass
            
            # if text_95 is stopping this frame...
            if text_95.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_95.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_95.tStop = t  # not accounting for scr refresh
                    text_95.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_95.stopped')
                    # update status
                    text_95.status = FINISHED
                    text_95.setAutoDraw(False)
            
            # *text_100* updates
            
            # if text_100 is starting this frame...
            if text_100.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_100.frameNStart = frameN  # exact frame index
                text_100.tStart = t  # local t and not account for scr refresh
                text_100.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_100, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_100.started')
                # update status
                text_100.status = STARTED
                text_100.setAutoDraw(True)
            
            # if text_100 is active this frame...
            if text_100.status == STARTED:
                # update params
                pass
            
            # if text_100 is stopping this frame...
            if text_100.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_100.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_100.tStop = t  # not accounting for scr refresh
                    text_100.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_100.stopped')
                    # update status
                    text_100.status = FINISHED
                    text_100.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Judge11Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Judge11" ---
        for thisComponent in Judge11Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Judge11.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_2'
    
    
    # --- Prepare to start Routine "Instruction12" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Instruction12.started', globalClock.getTime())
    key_resp_9.keys = []
    key_resp_9.rt = []
    _key_resp_9_allKeys = []
    # keep track of which components have finished
    Instruction12Components = [text_25, text_26, text_27, key_resp_9]
    for thisComponent in Instruction12Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instruction12" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_25* updates
        
        # if text_25 is starting this frame...
        if text_25.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_25.frameNStart = frameN  # exact frame index
            text_25.tStart = t  # local t and not account for scr refresh
            text_25.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_25, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_25.started')
            # update status
            text_25.status = STARTED
            text_25.setAutoDraw(True)
        
        # if text_25 is active this frame...
        if text_25.status == STARTED:
            # update params
            pass
        
        # *text_26* updates
        
        # if text_26 is starting this frame...
        if text_26.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_26.frameNStart = frameN  # exact frame index
            text_26.tStart = t  # local t and not account for scr refresh
            text_26.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_26, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_26.started')
            # update status
            text_26.status = STARTED
            text_26.setAutoDraw(True)
        
        # if text_26 is active this frame...
        if text_26.status == STARTED:
            # update params
            pass
        
        # *text_27* updates
        
        # if text_27 is starting this frame...
        if text_27.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_27.frameNStart = frameN  # exact frame index
            text_27.tStart = t  # local t and not account for scr refresh
            text_27.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_27, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_27.started')
            # update status
            text_27.status = STARTED
            text_27.setAutoDraw(True)
        
        # if text_27 is active this frame...
        if text_27.status == STARTED:
            # update params
            pass
        
        # *key_resp_9* updates
        waitOnFlip = False
        
        # if key_resp_9 is starting this frame...
        if key_resp_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_9.frameNStart = frameN  # exact frame index
            key_resp_9.tStart = t  # local t and not account for scr refresh
            key_resp_9.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_9, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_9.started')
            # update status
            key_resp_9.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_9.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_9.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_9.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_9.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_9_allKeys.extend(theseKeys)
            if len(_key_resp_9_allKeys):
                key_resp_9.keys = _key_resp_9_allKeys[-1].name  # just the last key pressed
                key_resp_9.rt = _key_resp_9_allKeys[-1].rt
                key_resp_9.duration = _key_resp_9_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Instruction12Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instruction12" ---
    for thisComponent in Instruction12Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Instruction12.stopped', globalClock.getTime())
    # check responses
    if key_resp_9.keys in ['', [], None]:  # No response was made
        key_resp_9.keys = None
    thisExp.addData('key_resp_9.keys',key_resp_9.keys)
    if key_resp_9.keys != None:  # we had a response
        thisExp.addData('key_resp_9.rt', key_resp_9.rt)
        thisExp.addData('key_resp_9.duration', key_resp_9.duration)
    thisExp.nextEntry()
    # the Routine "Instruction12" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_4 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Task12.xlsx'),
        seed=None, name='trials_4')
    thisExp.addLoop(trials_4)  # add the loop to the experiment
    thisTrial_4 = trials_4.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
    if thisTrial_4 != None:
        for paramName in thisTrial_4:
            globals()[paramName] = thisTrial_4[paramName]
    
    for thisTrial_4 in trials_4:
        currentLoop = trials_4
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
        if thisTrial_4 != None:
            for paramName in thisTrial_4:
                globals()[paramName] = thisTrial_4[paramName]
        
        # --- Prepare to start Routine "Task12" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Task12.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_16
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        server_socket.sendall((str(MarkNumber)).encode('utf-8')+ b'\n')
        
        text_63.setText(word)
        key_resp_16.keys = []
        key_resp_16.rt = []
        _key_resp_16_allKeys = []
        # keep track of which components have finished
        Task12Components = [text_61, text_62, text_63, key_resp_16]
        for thisComponent in Task12Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Task12" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_61* updates
            
            # if text_61 is starting this frame...
            if text_61.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_61.frameNStart = frameN  # exact frame index
                text_61.tStart = t  # local t and not account for scr refresh
                text_61.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_61, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_61.started')
                # update status
                text_61.status = STARTED
                text_61.setAutoDraw(True)
            
            # if text_61 is active this frame...
            if text_61.status == STARTED:
                # update params
                pass
            
            # *text_62* updates
            
            # if text_62 is starting this frame...
            if text_62.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_62.frameNStart = frameN  # exact frame index
                text_62.tStart = t  # local t and not account for scr refresh
                text_62.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_62, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_62.started')
                # update status
                text_62.status = STARTED
                text_62.setAutoDraw(True)
            
            # if text_62 is active this frame...
            if text_62.status == STARTED:
                # update params
                pass
            
            # *text_63* updates
            
            # if text_63 is starting this frame...
            if text_63.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_63.frameNStart = frameN  # exact frame index
                text_63.tStart = t  # local t and not account for scr refresh
                text_63.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_63, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_63.started')
                # update status
                text_63.status = STARTED
                text_63.setAutoDraw(True)
            
            # if text_63 is active this frame...
            if text_63.status == STARTED:
                # update params
                pass
            
            # *key_resp_16* updates
            waitOnFlip = False
            
            # if key_resp_16 is starting this frame...
            if key_resp_16.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_16.frameNStart = frameN  # exact frame index
                key_resp_16.tStart = t  # local t and not account for scr refresh
                key_resp_16.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_16, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_16.started')
                # update status
                key_resp_16.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_16.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_16.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_16.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_16.getKeys(keyList=['e','i'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_16_allKeys.extend(theseKeys)
                if len(_key_resp_16_allKeys):
                    key_resp_16.keys = _key_resp_16_allKeys[-1].name  # just the last key pressed
                    key_resp_16.rt = _key_resp_16_allKeys[-1].rt
                    key_resp_16.duration = _key_resp_16_allKeys[-1].duration
                    # was this correct?
                    if (key_resp_16.keys == str(answer)) or (key_resp_16.keys == answer):
                        key_resp_16.corr = 1
                    else:
                        key_resp_16.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Task12Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Task12" ---
        for thisComponent in Task12Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Task12.stopped', globalClock.getTime())
        # check responses
        if key_resp_16.keys in ['', [], None]:  # No response was made
            key_resp_16.keys = None
            # was no response the correct answer?!
            if str(answer).lower() == 'none':
               key_resp_16.corr = 1;  # correct non-response
            else:
               key_resp_16.corr = 0;  # failed to respond (incorrectly)
        # store data for trials_4 (TrialHandler)
        trials_4.addData('key_resp_16.keys',key_resp_16.keys)
        trials_4.addData('key_resp_16.corr', key_resp_16.corr)
        if key_resp_16.keys != None:  # we had a response
            trials_4.addData('key_resp_16.rt', key_resp_16.rt)
            trials_4.addData('key_resp_16.duration', key_resp_16.duration)
        # the Routine "Task12" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Judge12" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Judge12.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_5
        if key_resp_16.corr==1:
            feedback = '√'
            server_socket.sendall((str(correctTask1)).encode('utf-8')+ b'\n')
        else:
            feedback = '×'
            server_socket.sendall((str(wrongTask1)).encode('utf-8')+ b'\n')
        text_103.setText(word)
        text_104.setText(feedback)
        # keep track of which components have finished
        Judge12Components = [text_101, text_102, text_103, text_104]
        for thisComponent in Judge12Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Judge12" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_101* updates
            
            # if text_101 is starting this frame...
            if text_101.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_101.frameNStart = frameN  # exact frame index
                text_101.tStart = t  # local t and not account for scr refresh
                text_101.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_101, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_101.started')
                # update status
                text_101.status = STARTED
                text_101.setAutoDraw(True)
            
            # if text_101 is active this frame...
            if text_101.status == STARTED:
                # update params
                pass
            
            # if text_101 is stopping this frame...
            if text_101.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_101.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_101.tStop = t  # not accounting for scr refresh
                    text_101.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_101.stopped')
                    # update status
                    text_101.status = FINISHED
                    text_101.setAutoDraw(False)
            
            # *text_102* updates
            
            # if text_102 is starting this frame...
            if text_102.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_102.frameNStart = frameN  # exact frame index
                text_102.tStart = t  # local t and not account for scr refresh
                text_102.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_102, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_102.started')
                # update status
                text_102.status = STARTED
                text_102.setAutoDraw(True)
            
            # if text_102 is active this frame...
            if text_102.status == STARTED:
                # update params
                pass
            
            # if text_102 is stopping this frame...
            if text_102.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_102.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_102.tStop = t  # not accounting for scr refresh
                    text_102.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_102.stopped')
                    # update status
                    text_102.status = FINISHED
                    text_102.setAutoDraw(False)
            
            # *text_103* updates
            
            # if text_103 is starting this frame...
            if text_103.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                text_103.frameNStart = frameN  # exact frame index
                text_103.tStart = t  # local t and not account for scr refresh
                text_103.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_103, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_103.started')
                # update status
                text_103.status = STARTED
                text_103.setAutoDraw(True)
            
            # if text_103 is active this frame...
            if text_103.status == STARTED:
                # update params
                pass
            
            # if text_103 is stopping this frame...
            if text_103.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_103.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_103.tStop = t  # not accounting for scr refresh
                    text_103.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_103.stopped')
                    # update status
                    text_103.status = FINISHED
                    text_103.setAutoDraw(False)
            
            # *text_104* updates
            
            # if text_104 is starting this frame...
            if text_104.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_104.frameNStart = frameN  # exact frame index
                text_104.tStart = t  # local t and not account for scr refresh
                text_104.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_104, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_104.started')
                # update status
                text_104.status = STARTED
                text_104.setAutoDraw(True)
            
            # if text_104 is active this frame...
            if text_104.status == STARTED:
                # update params
                pass
            
            # if text_104 is stopping this frame...
            if text_104.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_104.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_104.tStop = t  # not accounting for scr refresh
                    text_104.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_104.stopped')
                    # update status
                    text_104.status = FINISHED
                    text_104.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Judge12Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Judge12" ---
        for thisComponent in Judge12Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Judge12.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_4'
    
    
    # --- Prepare to start Routine "Instruction13" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Instruction13.started', globalClock.getTime())
    key_resp_10.keys = []
    key_resp_10.rt = []
    _key_resp_10_allKeys = []
    # keep track of which components have finished
    Instruction13Components = [text_29, text_30, text_31, text_32, text_33, text_34, text_35, key_resp_10]
    for thisComponent in Instruction13Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instruction13" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_29* updates
        
        # if text_29 is starting this frame...
        if text_29.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_29.frameNStart = frameN  # exact frame index
            text_29.tStart = t  # local t and not account for scr refresh
            text_29.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_29, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_29.started')
            # update status
            text_29.status = STARTED
            text_29.setAutoDraw(True)
        
        # if text_29 is active this frame...
        if text_29.status == STARTED:
            # update params
            pass
        
        # *text_30* updates
        
        # if text_30 is starting this frame...
        if text_30.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_30.frameNStart = frameN  # exact frame index
            text_30.tStart = t  # local t and not account for scr refresh
            text_30.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_30, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_30.started')
            # update status
            text_30.status = STARTED
            text_30.setAutoDraw(True)
        
        # if text_30 is active this frame...
        if text_30.status == STARTED:
            # update params
            pass
        
        # *text_31* updates
        
        # if text_31 is starting this frame...
        if text_31.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_31.frameNStart = frameN  # exact frame index
            text_31.tStart = t  # local t and not account for scr refresh
            text_31.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_31, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_31.started')
            # update status
            text_31.status = STARTED
            text_31.setAutoDraw(True)
        
        # if text_31 is active this frame...
        if text_31.status == STARTED:
            # update params
            pass
        
        # *text_32* updates
        
        # if text_32 is starting this frame...
        if text_32.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_32.frameNStart = frameN  # exact frame index
            text_32.tStart = t  # local t and not account for scr refresh
            text_32.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_32, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_32.started')
            # update status
            text_32.status = STARTED
            text_32.setAutoDraw(True)
        
        # if text_32 is active this frame...
        if text_32.status == STARTED:
            # update params
            pass
        
        # *text_33* updates
        
        # if text_33 is starting this frame...
        if text_33.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_33.frameNStart = frameN  # exact frame index
            text_33.tStart = t  # local t and not account for scr refresh
            text_33.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_33, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_33.started')
            # update status
            text_33.status = STARTED
            text_33.setAutoDraw(True)
        
        # if text_33 is active this frame...
        if text_33.status == STARTED:
            # update params
            pass
        
        # *text_34* updates
        
        # if text_34 is starting this frame...
        if text_34.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_34.frameNStart = frameN  # exact frame index
            text_34.tStart = t  # local t and not account for scr refresh
            text_34.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_34, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_34.started')
            # update status
            text_34.status = STARTED
            text_34.setAutoDraw(True)
        
        # if text_34 is active this frame...
        if text_34.status == STARTED:
            # update params
            pass
        
        # *text_35* updates
        
        # if text_35 is starting this frame...
        if text_35.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_35.frameNStart = frameN  # exact frame index
            text_35.tStart = t  # local t and not account for scr refresh
            text_35.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_35, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_35.started')
            # update status
            text_35.status = STARTED
            text_35.setAutoDraw(True)
        
        # if text_35 is active this frame...
        if text_35.status == STARTED:
            # update params
            pass
        
        # *key_resp_10* updates
        waitOnFlip = False
        
        # if key_resp_10 is starting this frame...
        if key_resp_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_10.frameNStart = frameN  # exact frame index
            key_resp_10.tStart = t  # local t and not account for scr refresh
            key_resp_10.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_10, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_10.started')
            # update status
            key_resp_10.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_10.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_10.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_10.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_10.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_10_allKeys.extend(theseKeys)
            if len(_key_resp_10_allKeys):
                key_resp_10.keys = _key_resp_10_allKeys[-1].name  # just the last key pressed
                key_resp_10.rt = _key_resp_10_allKeys[-1].rt
                key_resp_10.duration = _key_resp_10_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Instruction13Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instruction13" ---
    for thisComponent in Instruction13Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Instruction13.stopped', globalClock.getTime())
    # check responses
    if key_resp_10.keys in ['', [], None]:  # No response was made
        key_resp_10.keys = None
    thisExp.addData('key_resp_10.keys',key_resp_10.keys)
    if key_resp_10.keys != None:  # we had a response
        thisExp.addData('key_resp_10.rt', key_resp_10.rt)
        thisExp.addData('key_resp_10.duration', key_resp_10.duration)
    thisExp.nextEntry()
    # the Routine "Instruction13" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_5 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Task13-14.xlsx'),
        seed=None, name='trials_5')
    thisExp.addLoop(trials_5)  # add the loop to the experiment
    thisTrial_5 = trials_5.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_5.rgb)
    if thisTrial_5 != None:
        for paramName in thisTrial_5:
            globals()[paramName] = thisTrial_5[paramName]
    
    for thisTrial_5 in trials_5:
        currentLoop = trials_5
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_5.rgb)
        if thisTrial_5 != None:
            for paramName in thisTrial_5:
                globals()[paramName] = thisTrial_5[paramName]
        
        # --- Prepare to start Routine "Task13" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Task13.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_17
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        server_socket.sendall((str(MarkNumber)).encode('utf-8')+ b'\n')
        
        text_70.setColor(color, colorSpace='rgb')
        text_70.setText(word)
        key_resp_17.keys = []
        key_resp_17.rt = []
        _key_resp_17_allKeys = []
        # keep track of which components have finished
        Task13Components = [text_64, text_65, text_66, text_67, text_68, text_69, text_70, key_resp_17]
        for thisComponent in Task13Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Task13" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_64* updates
            
            # if text_64 is starting this frame...
            if text_64.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_64.frameNStart = frameN  # exact frame index
                text_64.tStart = t  # local t and not account for scr refresh
                text_64.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_64, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_64.started')
                # update status
                text_64.status = STARTED
                text_64.setAutoDraw(True)
            
            # if text_64 is active this frame...
            if text_64.status == STARTED:
                # update params
                pass
            
            # *text_65* updates
            
            # if text_65 is starting this frame...
            if text_65.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_65.frameNStart = frameN  # exact frame index
                text_65.tStart = t  # local t and not account for scr refresh
                text_65.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_65, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_65.started')
                # update status
                text_65.status = STARTED
                text_65.setAutoDraw(True)
            
            # if text_65 is active this frame...
            if text_65.status == STARTED:
                # update params
                pass
            
            # *text_66* updates
            
            # if text_66 is starting this frame...
            if text_66.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_66.frameNStart = frameN  # exact frame index
                text_66.tStart = t  # local t and not account for scr refresh
                text_66.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_66, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_66.started')
                # update status
                text_66.status = STARTED
                text_66.setAutoDraw(True)
            
            # if text_66 is active this frame...
            if text_66.status == STARTED:
                # update params
                pass
            
            # *text_67* updates
            
            # if text_67 is starting this frame...
            if text_67.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_67.frameNStart = frameN  # exact frame index
                text_67.tStart = t  # local t and not account for scr refresh
                text_67.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_67, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_67.started')
                # update status
                text_67.status = STARTED
                text_67.setAutoDraw(True)
            
            # if text_67 is active this frame...
            if text_67.status == STARTED:
                # update params
                pass
            
            # *text_68* updates
            
            # if text_68 is starting this frame...
            if text_68.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_68.frameNStart = frameN  # exact frame index
                text_68.tStart = t  # local t and not account for scr refresh
                text_68.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_68, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_68.started')
                # update status
                text_68.status = STARTED
                text_68.setAutoDraw(True)
            
            # if text_68 is active this frame...
            if text_68.status == STARTED:
                # update params
                pass
            
            # *text_69* updates
            
            # if text_69 is starting this frame...
            if text_69.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_69.frameNStart = frameN  # exact frame index
                text_69.tStart = t  # local t and not account for scr refresh
                text_69.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_69, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_69.started')
                # update status
                text_69.status = STARTED
                text_69.setAutoDraw(True)
            
            # if text_69 is active this frame...
            if text_69.status == STARTED:
                # update params
                pass
            
            # *text_70* updates
            
            # if text_70 is starting this frame...
            if text_70.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_70.frameNStart = frameN  # exact frame index
                text_70.tStart = t  # local t and not account for scr refresh
                text_70.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_70, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_70.started')
                # update status
                text_70.status = STARTED
                text_70.setAutoDraw(True)
            
            # if text_70 is active this frame...
            if text_70.status == STARTED:
                # update params
                pass
            
            # *key_resp_17* updates
            waitOnFlip = False
            
            # if key_resp_17 is starting this frame...
            if key_resp_17.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_17.frameNStart = frameN  # exact frame index
                key_resp_17.tStart = t  # local t and not account for scr refresh
                key_resp_17.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_17, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_17.started')
                # update status
                key_resp_17.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_17.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_17.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_17.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_17.getKeys(keyList=['e','i'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_17_allKeys.extend(theseKeys)
                if len(_key_resp_17_allKeys):
                    key_resp_17.keys = _key_resp_17_allKeys[-1].name  # just the last key pressed
                    key_resp_17.rt = _key_resp_17_allKeys[-1].rt
                    key_resp_17.duration = _key_resp_17_allKeys[-1].duration
                    # was this correct?
                    if (key_resp_17.keys == str(answer)) or (key_resp_17.keys == answer):
                        key_resp_17.corr = 1
                    else:
                        key_resp_17.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Task13Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Task13" ---
        for thisComponent in Task13Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Task13.stopped', globalClock.getTime())
        # check responses
        if key_resp_17.keys in ['', [], None]:  # No response was made
            key_resp_17.keys = None
            # was no response the correct answer?!
            if str(answer).lower() == 'none':
               key_resp_17.corr = 1;  # correct non-response
            else:
               key_resp_17.corr = 0;  # failed to respond (incorrectly)
        # store data for trials_5 (TrialHandler)
        trials_5.addData('key_resp_17.keys',key_resp_17.keys)
        trials_5.addData('key_resp_17.corr', key_resp_17.corr)
        if key_resp_17.keys != None:  # we had a response
            trials_5.addData('key_resp_17.rt', key_resp_17.rt)
            trials_5.addData('key_resp_17.duration', key_resp_17.duration)
        # the Routine "Task13" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Judge13" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Judge13.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_6
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        if key_resp_17.corr==1:
            feedback = '√'
            server_socket.sendall((str(correctTask1)).encode('utf-8')+ b'\n')
        else:
            feedback = '×'
            server_socket.sendall((str(wrongTask1)).encode('utf-8')+ b'\n')
        text_111.setColor(color, colorSpace='rgb')
        text_111.setText(word)
        text_112.setText(feedback)
        # keep track of which components have finished
        Judge13Components = [text_105, text_106, text_107, text_108, text_109, text_110, text_111, text_112]
        for thisComponent in Judge13Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Judge13" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_105* updates
            
            # if text_105 is starting this frame...
            if text_105.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_105.frameNStart = frameN  # exact frame index
                text_105.tStart = t  # local t and not account for scr refresh
                text_105.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_105, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_105.started')
                # update status
                text_105.status = STARTED
                text_105.setAutoDraw(True)
            
            # if text_105 is active this frame...
            if text_105.status == STARTED:
                # update params
                pass
            
            # if text_105 is stopping this frame...
            if text_105.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_105.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_105.tStop = t  # not accounting for scr refresh
                    text_105.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_105.stopped')
                    # update status
                    text_105.status = FINISHED
                    text_105.setAutoDraw(False)
            
            # *text_106* updates
            
            # if text_106 is starting this frame...
            if text_106.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_106.frameNStart = frameN  # exact frame index
                text_106.tStart = t  # local t and not account for scr refresh
                text_106.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_106, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_106.started')
                # update status
                text_106.status = STARTED
                text_106.setAutoDraw(True)
            
            # if text_106 is active this frame...
            if text_106.status == STARTED:
                # update params
                pass
            
            # if text_106 is stopping this frame...
            if text_106.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_106.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_106.tStop = t  # not accounting for scr refresh
                    text_106.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_106.stopped')
                    # update status
                    text_106.status = FINISHED
                    text_106.setAutoDraw(False)
            
            # *text_107* updates
            
            # if text_107 is starting this frame...
            if text_107.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_107.frameNStart = frameN  # exact frame index
                text_107.tStart = t  # local t and not account for scr refresh
                text_107.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_107, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_107.started')
                # update status
                text_107.status = STARTED
                text_107.setAutoDraw(True)
            
            # if text_107 is active this frame...
            if text_107.status == STARTED:
                # update params
                pass
            
            # if text_107 is stopping this frame...
            if text_107.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_107.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_107.tStop = t  # not accounting for scr refresh
                    text_107.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_107.stopped')
                    # update status
                    text_107.status = FINISHED
                    text_107.setAutoDraw(False)
            
            # *text_108* updates
            
            # if text_108 is starting this frame...
            if text_108.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_108.frameNStart = frameN  # exact frame index
                text_108.tStart = t  # local t and not account for scr refresh
                text_108.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_108, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_108.started')
                # update status
                text_108.status = STARTED
                text_108.setAutoDraw(True)
            
            # if text_108 is active this frame...
            if text_108.status == STARTED:
                # update params
                pass
            
            # if text_108 is stopping this frame...
            if text_108.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_108.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_108.tStop = t  # not accounting for scr refresh
                    text_108.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_108.stopped')
                    # update status
                    text_108.status = FINISHED
                    text_108.setAutoDraw(False)
            
            # *text_109* updates
            
            # if text_109 is starting this frame...
            if text_109.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_109.frameNStart = frameN  # exact frame index
                text_109.tStart = t  # local t and not account for scr refresh
                text_109.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_109, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_109.started')
                # update status
                text_109.status = STARTED
                text_109.setAutoDraw(True)
            
            # if text_109 is active this frame...
            if text_109.status == STARTED:
                # update params
                pass
            
            # if text_109 is stopping this frame...
            if text_109.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_109.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_109.tStop = t  # not accounting for scr refresh
                    text_109.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_109.stopped')
                    # update status
                    text_109.status = FINISHED
                    text_109.setAutoDraw(False)
            
            # *text_110* updates
            
            # if text_110 is starting this frame...
            if text_110.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_110.frameNStart = frameN  # exact frame index
                text_110.tStart = t  # local t and not account for scr refresh
                text_110.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_110, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_110.started')
                # update status
                text_110.status = STARTED
                text_110.setAutoDraw(True)
            
            # if text_110 is active this frame...
            if text_110.status == STARTED:
                # update params
                pass
            
            # if text_110 is stopping this frame...
            if text_110.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_110.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_110.tStop = t  # not accounting for scr refresh
                    text_110.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_110.stopped')
                    # update status
                    text_110.status = FINISHED
                    text_110.setAutoDraw(False)
            
            # *text_111* updates
            
            # if text_111 is starting this frame...
            if text_111.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_111.frameNStart = frameN  # exact frame index
                text_111.tStart = t  # local t and not account for scr refresh
                text_111.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_111, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_111.started')
                # update status
                text_111.status = STARTED
                text_111.setAutoDraw(True)
            
            # if text_111 is active this frame...
            if text_111.status == STARTED:
                # update params
                pass
            
            # if text_111 is stopping this frame...
            if text_111.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_111.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_111.tStop = t  # not accounting for scr refresh
                    text_111.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_111.stopped')
                    # update status
                    text_111.status = FINISHED
                    text_111.setAutoDraw(False)
            
            # *text_112* updates
            
            # if text_112 is starting this frame...
            if text_112.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_112.frameNStart = frameN  # exact frame index
                text_112.tStart = t  # local t and not account for scr refresh
                text_112.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_112, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_112.started')
                # update status
                text_112.status = STARTED
                text_112.setAutoDraw(True)
            
            # if text_112 is active this frame...
            if text_112.status == STARTED:
                # update params
                pass
            
            # if text_112 is stopping this frame...
            if text_112.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_112.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_112.tStop = t  # not accounting for scr refresh
                    text_112.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_112.stopped')
                    # update status
                    text_112.status = FINISHED
                    text_112.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Judge13Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Judge13" ---
        for thisComponent in Judge13Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Judge13.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_5'
    
    
    # --- Prepare to start Routine "Instruction14" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Instruction14.started', globalClock.getTime())
    key_resp_11.keys = []
    key_resp_11.rt = []
    _key_resp_11_allKeys = []
    # keep track of which components have finished
    Instruction14Components = [text_36, text_37, text_38, text_39, text_40, text_41, text_42, key_resp_11]
    for thisComponent in Instruction14Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instruction14" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_36* updates
        
        # if text_36 is starting this frame...
        if text_36.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_36.frameNStart = frameN  # exact frame index
            text_36.tStart = t  # local t and not account for scr refresh
            text_36.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_36, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_36.started')
            # update status
            text_36.status = STARTED
            text_36.setAutoDraw(True)
        
        # if text_36 is active this frame...
        if text_36.status == STARTED:
            # update params
            pass
        
        # *text_37* updates
        
        # if text_37 is starting this frame...
        if text_37.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_37.frameNStart = frameN  # exact frame index
            text_37.tStart = t  # local t and not account for scr refresh
            text_37.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_37, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_37.started')
            # update status
            text_37.status = STARTED
            text_37.setAutoDraw(True)
        
        # if text_37 is active this frame...
        if text_37.status == STARTED:
            # update params
            pass
        
        # *text_38* updates
        
        # if text_38 is starting this frame...
        if text_38.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_38.frameNStart = frameN  # exact frame index
            text_38.tStart = t  # local t and not account for scr refresh
            text_38.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_38, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_38.started')
            # update status
            text_38.status = STARTED
            text_38.setAutoDraw(True)
        
        # if text_38 is active this frame...
        if text_38.status == STARTED:
            # update params
            pass
        
        # *text_39* updates
        
        # if text_39 is starting this frame...
        if text_39.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_39.frameNStart = frameN  # exact frame index
            text_39.tStart = t  # local t and not account for scr refresh
            text_39.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_39, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_39.started')
            # update status
            text_39.status = STARTED
            text_39.setAutoDraw(True)
        
        # if text_39 is active this frame...
        if text_39.status == STARTED:
            # update params
            pass
        
        # *text_40* updates
        
        # if text_40 is starting this frame...
        if text_40.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_40.frameNStart = frameN  # exact frame index
            text_40.tStart = t  # local t and not account for scr refresh
            text_40.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_40, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_40.started')
            # update status
            text_40.status = STARTED
            text_40.setAutoDraw(True)
        
        # if text_40 is active this frame...
        if text_40.status == STARTED:
            # update params
            pass
        
        # *text_41* updates
        
        # if text_41 is starting this frame...
        if text_41.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_41.frameNStart = frameN  # exact frame index
            text_41.tStart = t  # local t and not account for scr refresh
            text_41.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_41, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_41.started')
            # update status
            text_41.status = STARTED
            text_41.setAutoDraw(True)
        
        # if text_41 is active this frame...
        if text_41.status == STARTED:
            # update params
            pass
        
        # *text_42* updates
        
        # if text_42 is starting this frame...
        if text_42.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_42.frameNStart = frameN  # exact frame index
            text_42.tStart = t  # local t and not account for scr refresh
            text_42.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_42, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_42.started')
            # update status
            text_42.status = STARTED
            text_42.setAutoDraw(True)
        
        # if text_42 is active this frame...
        if text_42.status == STARTED:
            # update params
            pass
        
        # *key_resp_11* updates
        waitOnFlip = False
        
        # if key_resp_11 is starting this frame...
        if key_resp_11.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_11.frameNStart = frameN  # exact frame index
            key_resp_11.tStart = t  # local t and not account for scr refresh
            key_resp_11.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_11, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_11.started')
            # update status
            key_resp_11.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_11.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_11.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_11.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_11.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_11_allKeys.extend(theseKeys)
            if len(_key_resp_11_allKeys):
                key_resp_11.keys = _key_resp_11_allKeys[-1].name  # just the last key pressed
                key_resp_11.rt = _key_resp_11_allKeys[-1].rt
                key_resp_11.duration = _key_resp_11_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Instruction14Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instruction14" ---
    for thisComponent in Instruction14Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Instruction14.stopped', globalClock.getTime())
    # check responses
    if key_resp_11.keys in ['', [], None]:  # No response was made
        key_resp_11.keys = None
    thisExp.addData('key_resp_11.keys',key_resp_11.keys)
    if key_resp_11.keys != None:  # we had a response
        thisExp.addData('key_resp_11.rt', key_resp_11.rt)
        thisExp.addData('key_resp_11.duration', key_resp_11.duration)
    thisExp.nextEntry()
    # the Routine "Instruction14" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_6 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Task13-14.xlsx'),
        seed=None, name='trials_6')
    thisExp.addLoop(trials_6)  # add the loop to the experiment
    thisTrial_6 = trials_6.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_6.rgb)
    if thisTrial_6 != None:
        for paramName in thisTrial_6:
            globals()[paramName] = thisTrial_6[paramName]
    
    for thisTrial_6 in trials_6:
        currentLoop = trials_6
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_6.rgb)
        if thisTrial_6 != None:
            for paramName in thisTrial_6:
                globals()[paramName] = thisTrial_6[paramName]
        
        # --- Prepare to start Routine "Task14" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Task14.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_18
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        server_socket.sendall((str(MarkNumber)).encode('utf-8')+ b'\n')
        
        text_77.setColor(color, colorSpace='rgb')
        text_77.setText(word)
        key_resp_21.keys = []
        key_resp_21.rt = []
        _key_resp_21_allKeys = []
        # keep track of which components have finished
        Task14Components = [text_71, text_72, text_73, text_74, text_75, text_76, text_77, key_resp_21]
        for thisComponent in Task14Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Task14" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_71* updates
            
            # if text_71 is starting this frame...
            if text_71.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_71.frameNStart = frameN  # exact frame index
                text_71.tStart = t  # local t and not account for scr refresh
                text_71.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_71, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_71.started')
                # update status
                text_71.status = STARTED
                text_71.setAutoDraw(True)
            
            # if text_71 is active this frame...
            if text_71.status == STARTED:
                # update params
                pass
            
            # *text_72* updates
            
            # if text_72 is starting this frame...
            if text_72.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_72.frameNStart = frameN  # exact frame index
                text_72.tStart = t  # local t and not account for scr refresh
                text_72.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_72, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_72.started')
                # update status
                text_72.status = STARTED
                text_72.setAutoDraw(True)
            
            # if text_72 is active this frame...
            if text_72.status == STARTED:
                # update params
                pass
            
            # *text_73* updates
            
            # if text_73 is starting this frame...
            if text_73.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_73.frameNStart = frameN  # exact frame index
                text_73.tStart = t  # local t and not account for scr refresh
                text_73.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_73, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_73.started')
                # update status
                text_73.status = STARTED
                text_73.setAutoDraw(True)
            
            # if text_73 is active this frame...
            if text_73.status == STARTED:
                # update params
                pass
            
            # *text_74* updates
            
            # if text_74 is starting this frame...
            if text_74.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_74.frameNStart = frameN  # exact frame index
                text_74.tStart = t  # local t and not account for scr refresh
                text_74.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_74, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_74.started')
                # update status
                text_74.status = STARTED
                text_74.setAutoDraw(True)
            
            # if text_74 is active this frame...
            if text_74.status == STARTED:
                # update params
                pass
            
            # *text_75* updates
            
            # if text_75 is starting this frame...
            if text_75.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_75.frameNStart = frameN  # exact frame index
                text_75.tStart = t  # local t and not account for scr refresh
                text_75.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_75, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_75.started')
                # update status
                text_75.status = STARTED
                text_75.setAutoDraw(True)
            
            # if text_75 is active this frame...
            if text_75.status == STARTED:
                # update params
                pass
            
            # *text_76* updates
            
            # if text_76 is starting this frame...
            if text_76.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_76.frameNStart = frameN  # exact frame index
                text_76.tStart = t  # local t and not account for scr refresh
                text_76.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_76, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_76.started')
                # update status
                text_76.status = STARTED
                text_76.setAutoDraw(True)
            
            # if text_76 is active this frame...
            if text_76.status == STARTED:
                # update params
                pass
            
            # *text_77* updates
            
            # if text_77 is starting this frame...
            if text_77.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_77.frameNStart = frameN  # exact frame index
                text_77.tStart = t  # local t and not account for scr refresh
                text_77.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_77, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_77.started')
                # update status
                text_77.status = STARTED
                text_77.setAutoDraw(True)
            
            # if text_77 is active this frame...
            if text_77.status == STARTED:
                # update params
                pass
            
            # *key_resp_21* updates
            waitOnFlip = False
            
            # if key_resp_21 is starting this frame...
            if key_resp_21.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_21.frameNStart = frameN  # exact frame index
                key_resp_21.tStart = t  # local t and not account for scr refresh
                key_resp_21.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_21, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_21.started')
                # update status
                key_resp_21.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_21.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_21.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_21.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_21.getKeys(keyList=['e','i'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_21_allKeys.extend(theseKeys)
                if len(_key_resp_21_allKeys):
                    key_resp_21.keys = _key_resp_21_allKeys[-1].name  # just the last key pressed
                    key_resp_21.rt = _key_resp_21_allKeys[-1].rt
                    key_resp_21.duration = _key_resp_21_allKeys[-1].duration
                    # was this correct?
                    if (key_resp_21.keys == str(answer)) or (key_resp_21.keys == answer):
                        key_resp_21.corr = 1
                    else:
                        key_resp_21.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Task14Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Task14" ---
        for thisComponent in Task14Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Task14.stopped', globalClock.getTime())
        # check responses
        if key_resp_21.keys in ['', [], None]:  # No response was made
            key_resp_21.keys = None
            # was no response the correct answer?!
            if str(answer).lower() == 'none':
               key_resp_21.corr = 1;  # correct non-response
            else:
               key_resp_21.corr = 0;  # failed to respond (incorrectly)
        # store data for trials_6 (TrialHandler)
        trials_6.addData('key_resp_21.keys',key_resp_21.keys)
        trials_6.addData('key_resp_21.corr', key_resp_21.corr)
        if key_resp_21.keys != None:  # we had a response
            trials_6.addData('key_resp_21.rt', key_resp_21.rt)
            trials_6.addData('key_resp_21.duration', key_resp_21.duration)
        # the Routine "Task14" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Judge14" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Judge14.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_7
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        if key_resp_21.corr==1:
            feedback = '√'
            server_socket.sendall((str(correctTask1)).encode('utf-8')+ b'\n')
        else:
            feedback = '×'
            server_socket.sendall((str(wrongTask1)).encode('utf-8')+ b'\n')
        text_119.setColor(color, colorSpace='rgb')
        text_119.setText(word)
        text_120.setText(feedback)
        # keep track of which components have finished
        Judge14Components = [text_113, text_114, text_115, text_116, text_117, text_118, text_119, text_120]
        for thisComponent in Judge14Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Judge14" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_113* updates
            
            # if text_113 is starting this frame...
            if text_113.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_113.frameNStart = frameN  # exact frame index
                text_113.tStart = t  # local t and not account for scr refresh
                text_113.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_113, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_113.started')
                # update status
                text_113.status = STARTED
                text_113.setAutoDraw(True)
            
            # if text_113 is active this frame...
            if text_113.status == STARTED:
                # update params
                pass
            
            # if text_113 is stopping this frame...
            if text_113.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_113.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_113.tStop = t  # not accounting for scr refresh
                    text_113.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_113.stopped')
                    # update status
                    text_113.status = FINISHED
                    text_113.setAutoDraw(False)
            
            # *text_114* updates
            
            # if text_114 is starting this frame...
            if text_114.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_114.frameNStart = frameN  # exact frame index
                text_114.tStart = t  # local t and not account for scr refresh
                text_114.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_114, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_114.started')
                # update status
                text_114.status = STARTED
                text_114.setAutoDraw(True)
            
            # if text_114 is active this frame...
            if text_114.status == STARTED:
                # update params
                pass
            
            # if text_114 is stopping this frame...
            if text_114.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_114.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_114.tStop = t  # not accounting for scr refresh
                    text_114.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_114.stopped')
                    # update status
                    text_114.status = FINISHED
                    text_114.setAutoDraw(False)
            
            # *text_115* updates
            
            # if text_115 is starting this frame...
            if text_115.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_115.frameNStart = frameN  # exact frame index
                text_115.tStart = t  # local t and not account for scr refresh
                text_115.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_115, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_115.started')
                # update status
                text_115.status = STARTED
                text_115.setAutoDraw(True)
            
            # if text_115 is active this frame...
            if text_115.status == STARTED:
                # update params
                pass
            
            # if text_115 is stopping this frame...
            if text_115.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_115.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_115.tStop = t  # not accounting for scr refresh
                    text_115.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_115.stopped')
                    # update status
                    text_115.status = FINISHED
                    text_115.setAutoDraw(False)
            
            # *text_116* updates
            
            # if text_116 is starting this frame...
            if text_116.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_116.frameNStart = frameN  # exact frame index
                text_116.tStart = t  # local t and not account for scr refresh
                text_116.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_116, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_116.started')
                # update status
                text_116.status = STARTED
                text_116.setAutoDraw(True)
            
            # if text_116 is active this frame...
            if text_116.status == STARTED:
                # update params
                pass
            
            # if text_116 is stopping this frame...
            if text_116.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_116.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_116.tStop = t  # not accounting for scr refresh
                    text_116.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_116.stopped')
                    # update status
                    text_116.status = FINISHED
                    text_116.setAutoDraw(False)
            
            # *text_117* updates
            
            # if text_117 is starting this frame...
            if text_117.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_117.frameNStart = frameN  # exact frame index
                text_117.tStart = t  # local t and not account for scr refresh
                text_117.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_117, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_117.started')
                # update status
                text_117.status = STARTED
                text_117.setAutoDraw(True)
            
            # if text_117 is active this frame...
            if text_117.status == STARTED:
                # update params
                pass
            
            # if text_117 is stopping this frame...
            if text_117.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_117.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_117.tStop = t  # not accounting for scr refresh
                    text_117.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_117.stopped')
                    # update status
                    text_117.status = FINISHED
                    text_117.setAutoDraw(False)
            
            # *text_118* updates
            
            # if text_118 is starting this frame...
            if text_118.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_118.frameNStart = frameN  # exact frame index
                text_118.tStart = t  # local t and not account for scr refresh
                text_118.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_118, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_118.started')
                # update status
                text_118.status = STARTED
                text_118.setAutoDraw(True)
            
            # if text_118 is active this frame...
            if text_118.status == STARTED:
                # update params
                pass
            
            # if text_118 is stopping this frame...
            if text_118.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_118.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_118.tStop = t  # not accounting for scr refresh
                    text_118.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_118.stopped')
                    # update status
                    text_118.status = FINISHED
                    text_118.setAutoDraw(False)
            
            # *text_119* updates
            
            # if text_119 is starting this frame...
            if text_119.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_119.frameNStart = frameN  # exact frame index
                text_119.tStart = t  # local t and not account for scr refresh
                text_119.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_119, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_119.started')
                # update status
                text_119.status = STARTED
                text_119.setAutoDraw(True)
            
            # if text_119 is active this frame...
            if text_119.status == STARTED:
                # update params
                pass
            
            # if text_119 is stopping this frame...
            if text_119.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_119.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_119.tStop = t  # not accounting for scr refresh
                    text_119.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_119.stopped')
                    # update status
                    text_119.status = FINISHED
                    text_119.setAutoDraw(False)
            
            # *text_120* updates
            
            # if text_120 is starting this frame...
            if text_120.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_120.frameNStart = frameN  # exact frame index
                text_120.tStart = t  # local t and not account for scr refresh
                text_120.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_120, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_120.started')
                # update status
                text_120.status = STARTED
                text_120.setAutoDraw(True)
            
            # if text_120 is active this frame...
            if text_120.status == STARTED:
                # update params
                pass
            
            # if text_120 is stopping this frame...
            if text_120.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_120.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_120.tStop = t  # not accounting for scr refresh
                    text_120.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_120.stopped')
                    # update status
                    text_120.status = FINISHED
                    text_120.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Judge14Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Judge14" ---
        for thisComponent in Judge14Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Judge14.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_6'
    
    
    # --- Prepare to start Routine "Instruction15" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Instruction15.started', globalClock.getTime())
    key_resp_12.keys = []
    key_resp_12.rt = []
    _key_resp_12_allKeys = []
    # keep track of which components have finished
    Instruction15Components = [text_43, text_44, text_45, key_resp_12]
    for thisComponent in Instruction15Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instruction15" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_43* updates
        
        # if text_43 is starting this frame...
        if text_43.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_43.frameNStart = frameN  # exact frame index
            text_43.tStart = t  # local t and not account for scr refresh
            text_43.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_43, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_43.started')
            # update status
            text_43.status = STARTED
            text_43.setAutoDraw(True)
        
        # if text_43 is active this frame...
        if text_43.status == STARTED:
            # update params
            pass
        
        # *text_44* updates
        
        # if text_44 is starting this frame...
        if text_44.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_44.frameNStart = frameN  # exact frame index
            text_44.tStart = t  # local t and not account for scr refresh
            text_44.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_44, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_44.started')
            # update status
            text_44.status = STARTED
            text_44.setAutoDraw(True)
        
        # if text_44 is active this frame...
        if text_44.status == STARTED:
            # update params
            pass
        
        # *text_45* updates
        
        # if text_45 is starting this frame...
        if text_45.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_45.frameNStart = frameN  # exact frame index
            text_45.tStart = t  # local t and not account for scr refresh
            text_45.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_45, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_45.started')
            # update status
            text_45.status = STARTED
            text_45.setAutoDraw(True)
        
        # if text_45 is active this frame...
        if text_45.status == STARTED:
            # update params
            pass
        
        # *key_resp_12* updates
        waitOnFlip = False
        
        # if key_resp_12 is starting this frame...
        if key_resp_12.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_12.frameNStart = frameN  # exact frame index
            key_resp_12.tStart = t  # local t and not account for scr refresh
            key_resp_12.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_12, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_12.started')
            # update status
            key_resp_12.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_12.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_12.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_12.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_12.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_12_allKeys.extend(theseKeys)
            if len(_key_resp_12_allKeys):
                key_resp_12.keys = _key_resp_12_allKeys[-1].name  # just the last key pressed
                key_resp_12.rt = _key_resp_12_allKeys[-1].rt
                key_resp_12.duration = _key_resp_12_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Instruction15Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instruction15" ---
    for thisComponent in Instruction15Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Instruction15.stopped', globalClock.getTime())
    # check responses
    if key_resp_12.keys in ['', [], None]:  # No response was made
        key_resp_12.keys = None
    thisExp.addData('key_resp_12.keys',key_resp_12.keys)
    if key_resp_12.keys != None:  # we had a response
        thisExp.addData('key_resp_12.rt', key_resp_12.rt)
        thisExp.addData('key_resp_12.duration', key_resp_12.duration)
    thisExp.nextEntry()
    # the Routine "Instruction15" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_7 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Task15.xlsx'),
        seed=None, name='trials_7')
    thisExp.addLoop(trials_7)  # add the loop to the experiment
    thisTrial_7 = trials_7.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_7.rgb)
    if thisTrial_7 != None:
        for paramName in thisTrial_7:
            globals()[paramName] = thisTrial_7[paramName]
    
    for thisTrial_7 in trials_7:
        currentLoop = trials_7
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_7.rgb)
        if thisTrial_7 != None:
            for paramName in thisTrial_7:
                globals()[paramName] = thisTrial_7[paramName]
        
        # --- Prepare to start Routine "Task15" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Task15.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_20
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        server_socket.sendall((str(MarkNumber)).encode('utf-8')+ b'\n')
        
        text_80.setText(word)
        key_resp_18.keys = []
        key_resp_18.rt = []
        _key_resp_18_allKeys = []
        # keep track of which components have finished
        Task15Components = [text_78, text_79, text_80, key_resp_18]
        for thisComponent in Task15Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Task15" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_78* updates
            
            # if text_78 is starting this frame...
            if text_78.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_78.frameNStart = frameN  # exact frame index
                text_78.tStart = t  # local t and not account for scr refresh
                text_78.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_78, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_78.started')
                # update status
                text_78.status = STARTED
                text_78.setAutoDraw(True)
            
            # if text_78 is active this frame...
            if text_78.status == STARTED:
                # update params
                pass
            
            # *text_79* updates
            
            # if text_79 is starting this frame...
            if text_79.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_79.frameNStart = frameN  # exact frame index
                text_79.tStart = t  # local t and not account for scr refresh
                text_79.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_79, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_79.started')
                # update status
                text_79.status = STARTED
                text_79.setAutoDraw(True)
            
            # if text_79 is active this frame...
            if text_79.status == STARTED:
                # update params
                pass
            
            # *text_80* updates
            
            # if text_80 is starting this frame...
            if text_80.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_80.frameNStart = frameN  # exact frame index
                text_80.tStart = t  # local t and not account for scr refresh
                text_80.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_80, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_80.started')
                # update status
                text_80.status = STARTED
                text_80.setAutoDraw(True)
            
            # if text_80 is active this frame...
            if text_80.status == STARTED:
                # update params
                pass
            
            # *key_resp_18* updates
            waitOnFlip = False
            
            # if key_resp_18 is starting this frame...
            if key_resp_18.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_18.frameNStart = frameN  # exact frame index
                key_resp_18.tStart = t  # local t and not account for scr refresh
                key_resp_18.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_18, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_18.started')
                # update status
                key_resp_18.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_18.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_18.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_18.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_18.getKeys(keyList=['e','i'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_18_allKeys.extend(theseKeys)
                if len(_key_resp_18_allKeys):
                    key_resp_18.keys = _key_resp_18_allKeys[-1].name  # just the last key pressed
                    key_resp_18.rt = _key_resp_18_allKeys[-1].rt
                    key_resp_18.duration = _key_resp_18_allKeys[-1].duration
                    # was this correct?
                    if (key_resp_18.keys == str(answer)) or (key_resp_18.keys == answer):
                        key_resp_18.corr = 1
                    else:
                        key_resp_18.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Task15Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Task15" ---
        for thisComponent in Task15Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Task15.stopped', globalClock.getTime())
        # check responses
        if key_resp_18.keys in ['', [], None]:  # No response was made
            key_resp_18.keys = None
            # was no response the correct answer?!
            if str(answer).lower() == 'none':
               key_resp_18.corr = 1;  # correct non-response
            else:
               key_resp_18.corr = 0;  # failed to respond (incorrectly)
        # store data for trials_7 (TrialHandler)
        trials_7.addData('key_resp_18.keys',key_resp_18.keys)
        trials_7.addData('key_resp_18.corr', key_resp_18.corr)
        if key_resp_18.keys != None:  # we had a response
            trials_7.addData('key_resp_18.rt', key_resp_18.rt)
            trials_7.addData('key_resp_18.duration', key_resp_18.duration)
        # the Routine "Task15" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Judge15" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Judge15.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_8
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        if key_resp_18.corr==1:
            feedback = '√'
            server_socket.sendall((str(correctTask1)).encode('utf-8')+ b'\n')
        else:
            feedback = '×'
            server_socket.sendall((str(wrongTask1)).encode('utf-8')+ b'\n')
        text_123.setText(word)
        text_124.setText(feedback)
        # keep track of which components have finished
        Judge15Components = [text_121, text_122, text_123, text_124]
        for thisComponent in Judge15Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Judge15" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_121* updates
            
            # if text_121 is starting this frame...
            if text_121.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_121.frameNStart = frameN  # exact frame index
                text_121.tStart = t  # local t and not account for scr refresh
                text_121.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_121, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_121.started')
                # update status
                text_121.status = STARTED
                text_121.setAutoDraw(True)
            
            # if text_121 is active this frame...
            if text_121.status == STARTED:
                # update params
                pass
            
            # if text_121 is stopping this frame...
            if text_121.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_121.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_121.tStop = t  # not accounting for scr refresh
                    text_121.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_121.stopped')
                    # update status
                    text_121.status = FINISHED
                    text_121.setAutoDraw(False)
            
            # *text_122* updates
            
            # if text_122 is starting this frame...
            if text_122.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_122.frameNStart = frameN  # exact frame index
                text_122.tStart = t  # local t and not account for scr refresh
                text_122.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_122, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_122.started')
                # update status
                text_122.status = STARTED
                text_122.setAutoDraw(True)
            
            # if text_122 is active this frame...
            if text_122.status == STARTED:
                # update params
                pass
            
            # if text_122 is stopping this frame...
            if text_122.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_122.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_122.tStop = t  # not accounting for scr refresh
                    text_122.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_122.stopped')
                    # update status
                    text_122.status = FINISHED
                    text_122.setAutoDraw(False)
            
            # *text_123* updates
            
            # if text_123 is starting this frame...
            if text_123.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_123.frameNStart = frameN  # exact frame index
                text_123.tStart = t  # local t and not account for scr refresh
                text_123.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_123, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_123.started')
                # update status
                text_123.status = STARTED
                text_123.setAutoDraw(True)
            
            # if text_123 is active this frame...
            if text_123.status == STARTED:
                # update params
                pass
            
            # if text_123 is stopping this frame...
            if text_123.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_123.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_123.tStop = t  # not accounting for scr refresh
                    text_123.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_123.stopped')
                    # update status
                    text_123.status = FINISHED
                    text_123.setAutoDraw(False)
            
            # *text_124* updates
            
            # if text_124 is starting this frame...
            if text_124.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_124.frameNStart = frameN  # exact frame index
                text_124.tStart = t  # local t and not account for scr refresh
                text_124.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_124, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_124.started')
                # update status
                text_124.status = STARTED
                text_124.setAutoDraw(True)
            
            # if text_124 is active this frame...
            if text_124.status == STARTED:
                # update params
                pass
            
            # if text_124 is stopping this frame...
            if text_124.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_124.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_124.tStop = t  # not accounting for scr refresh
                    text_124.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_124.stopped')
                    # update status
                    text_124.status = FINISHED
                    text_124.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Judge15Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Judge15" ---
        for thisComponent in Judge15Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Judge15.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_7'
    
    
    # --- Prepare to start Routine "Instruction16" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Instruction16.started', globalClock.getTime())
    key_resp_13.keys = []
    key_resp_13.rt = []
    _key_resp_13_allKeys = []
    # keep track of which components have finished
    Instruction16Components = [text_46, text_47, text_48, text_49, text_50, text_51, text_59, key_resp_13]
    for thisComponent in Instruction16Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instruction16" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_46* updates
        
        # if text_46 is starting this frame...
        if text_46.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_46.frameNStart = frameN  # exact frame index
            text_46.tStart = t  # local t and not account for scr refresh
            text_46.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_46, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_46.started')
            # update status
            text_46.status = STARTED
            text_46.setAutoDraw(True)
        
        # if text_46 is active this frame...
        if text_46.status == STARTED:
            # update params
            pass
        
        # *text_47* updates
        
        # if text_47 is starting this frame...
        if text_47.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_47.frameNStart = frameN  # exact frame index
            text_47.tStart = t  # local t and not account for scr refresh
            text_47.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_47, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_47.started')
            # update status
            text_47.status = STARTED
            text_47.setAutoDraw(True)
        
        # if text_47 is active this frame...
        if text_47.status == STARTED:
            # update params
            pass
        
        # *text_48* updates
        
        # if text_48 is starting this frame...
        if text_48.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_48.frameNStart = frameN  # exact frame index
            text_48.tStart = t  # local t and not account for scr refresh
            text_48.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_48, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_48.started')
            # update status
            text_48.status = STARTED
            text_48.setAutoDraw(True)
        
        # if text_48 is active this frame...
        if text_48.status == STARTED:
            # update params
            pass
        
        # *text_49* updates
        
        # if text_49 is starting this frame...
        if text_49.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_49.frameNStart = frameN  # exact frame index
            text_49.tStart = t  # local t and not account for scr refresh
            text_49.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_49, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_49.started')
            # update status
            text_49.status = STARTED
            text_49.setAutoDraw(True)
        
        # if text_49 is active this frame...
        if text_49.status == STARTED:
            # update params
            pass
        
        # *text_50* updates
        
        # if text_50 is starting this frame...
        if text_50.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_50.frameNStart = frameN  # exact frame index
            text_50.tStart = t  # local t and not account for scr refresh
            text_50.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_50, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_50.started')
            # update status
            text_50.status = STARTED
            text_50.setAutoDraw(True)
        
        # if text_50 is active this frame...
        if text_50.status == STARTED:
            # update params
            pass
        
        # *text_51* updates
        
        # if text_51 is starting this frame...
        if text_51.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_51.frameNStart = frameN  # exact frame index
            text_51.tStart = t  # local t and not account for scr refresh
            text_51.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_51, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_51.started')
            # update status
            text_51.status = STARTED
            text_51.setAutoDraw(True)
        
        # if text_51 is active this frame...
        if text_51.status == STARTED:
            # update params
            pass
        
        # *text_59* updates
        
        # if text_59 is starting this frame...
        if text_59.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_59.frameNStart = frameN  # exact frame index
            text_59.tStart = t  # local t and not account for scr refresh
            text_59.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_59, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_59.started')
            # update status
            text_59.status = STARTED
            text_59.setAutoDraw(True)
        
        # if text_59 is active this frame...
        if text_59.status == STARTED:
            # update params
            pass
        
        # *key_resp_13* updates
        waitOnFlip = False
        
        # if key_resp_13 is starting this frame...
        if key_resp_13.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_13.frameNStart = frameN  # exact frame index
            key_resp_13.tStart = t  # local t and not account for scr refresh
            key_resp_13.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_13, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_13.started')
            # update status
            key_resp_13.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_13.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_13.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_13.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_13.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_13_allKeys.extend(theseKeys)
            if len(_key_resp_13_allKeys):
                key_resp_13.keys = _key_resp_13_allKeys[-1].name  # just the last key pressed
                key_resp_13.rt = _key_resp_13_allKeys[-1].rt
                key_resp_13.duration = _key_resp_13_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Instruction16Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instruction16" ---
    for thisComponent in Instruction16Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Instruction16.stopped', globalClock.getTime())
    # check responses
    if key_resp_13.keys in ['', [], None]:  # No response was made
        key_resp_13.keys = None
    thisExp.addData('key_resp_13.keys',key_resp_13.keys)
    if key_resp_13.keys != None:  # we had a response
        thisExp.addData('key_resp_13.rt', key_resp_13.rt)
        thisExp.addData('key_resp_13.duration', key_resp_13.duration)
    thisExp.nextEntry()
    # the Routine "Instruction16" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_8 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Task16-17.xlsx'),
        seed=None, name='trials_8')
    thisExp.addLoop(trials_8)  # add the loop to the experiment
    thisTrial_8 = trials_8.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_8.rgb)
    if thisTrial_8 != None:
        for paramName in thisTrial_8:
            globals()[paramName] = thisTrial_8[paramName]
    
    for thisTrial_8 in trials_8:
        currentLoop = trials_8
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_8.rgb)
        if thisTrial_8 != None:
            for paramName in thisTrial_8:
                globals()[paramName] = thisTrial_8[paramName]
        
        # --- Prepare to start Routine "Task16" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Task16.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_19
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        server_socket.sendall((str(MarkNumber)).encode('utf-8')+ b'\n')
        
        text_87.setColor(color, colorSpace='rgb')
        text_87.setText(word)
        key_resp_19.keys = []
        key_resp_19.rt = []
        _key_resp_19_allKeys = []
        # keep track of which components have finished
        Task16Components = [text_81, text_82, text_83, text_84, text_85, text_86, text_87, key_resp_19]
        for thisComponent in Task16Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Task16" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_81* updates
            
            # if text_81 is starting this frame...
            if text_81.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_81.frameNStart = frameN  # exact frame index
                text_81.tStart = t  # local t and not account for scr refresh
                text_81.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_81, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_81.started')
                # update status
                text_81.status = STARTED
                text_81.setAutoDraw(True)
            
            # if text_81 is active this frame...
            if text_81.status == STARTED:
                # update params
                pass
            
            # *text_82* updates
            
            # if text_82 is starting this frame...
            if text_82.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_82.frameNStart = frameN  # exact frame index
                text_82.tStart = t  # local t and not account for scr refresh
                text_82.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_82, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_82.started')
                # update status
                text_82.status = STARTED
                text_82.setAutoDraw(True)
            
            # if text_82 is active this frame...
            if text_82.status == STARTED:
                # update params
                pass
            
            # *text_83* updates
            
            # if text_83 is starting this frame...
            if text_83.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_83.frameNStart = frameN  # exact frame index
                text_83.tStart = t  # local t and not account for scr refresh
                text_83.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_83, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_83.started')
                # update status
                text_83.status = STARTED
                text_83.setAutoDraw(True)
            
            # if text_83 is active this frame...
            if text_83.status == STARTED:
                # update params
                pass
            
            # *text_84* updates
            
            # if text_84 is starting this frame...
            if text_84.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_84.frameNStart = frameN  # exact frame index
                text_84.tStart = t  # local t and not account for scr refresh
                text_84.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_84, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_84.started')
                # update status
                text_84.status = STARTED
                text_84.setAutoDraw(True)
            
            # if text_84 is active this frame...
            if text_84.status == STARTED:
                # update params
                pass
            
            # *text_85* updates
            
            # if text_85 is starting this frame...
            if text_85.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_85.frameNStart = frameN  # exact frame index
                text_85.tStart = t  # local t and not account for scr refresh
                text_85.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_85, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_85.started')
                # update status
                text_85.status = STARTED
                text_85.setAutoDraw(True)
            
            # if text_85 is active this frame...
            if text_85.status == STARTED:
                # update params
                pass
            
            # *text_86* updates
            
            # if text_86 is starting this frame...
            if text_86.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_86.frameNStart = frameN  # exact frame index
                text_86.tStart = t  # local t and not account for scr refresh
                text_86.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_86, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_86.started')
                # update status
                text_86.status = STARTED
                text_86.setAutoDraw(True)
            
            # if text_86 is active this frame...
            if text_86.status == STARTED:
                # update params
                pass
            
            # *text_87* updates
            
            # if text_87 is starting this frame...
            if text_87.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_87.frameNStart = frameN  # exact frame index
                text_87.tStart = t  # local t and not account for scr refresh
                text_87.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_87, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_87.started')
                # update status
                text_87.status = STARTED
                text_87.setAutoDraw(True)
            
            # if text_87 is active this frame...
            if text_87.status == STARTED:
                # update params
                pass
            
            # *key_resp_19* updates
            waitOnFlip = False
            
            # if key_resp_19 is starting this frame...
            if key_resp_19.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_19.frameNStart = frameN  # exact frame index
                key_resp_19.tStart = t  # local t and not account for scr refresh
                key_resp_19.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_19, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_19.started')
                # update status
                key_resp_19.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_19.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_19.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_19.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_19.getKeys(keyList=['e','i'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_19_allKeys.extend(theseKeys)
                if len(_key_resp_19_allKeys):
                    key_resp_19.keys = _key_resp_19_allKeys[-1].name  # just the last key pressed
                    key_resp_19.rt = _key_resp_19_allKeys[-1].rt
                    key_resp_19.duration = _key_resp_19_allKeys[-1].duration
                    # was this correct?
                    if (key_resp_19.keys == str(answer)) or (key_resp_19.keys == answer):
                        key_resp_19.corr = 1
                    else:
                        key_resp_19.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Task16Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Task16" ---
        for thisComponent in Task16Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Task16.stopped', globalClock.getTime())
        # check responses
        if key_resp_19.keys in ['', [], None]:  # No response was made
            key_resp_19.keys = None
            # was no response the correct answer?!
            if str(answer).lower() == 'none':
               key_resp_19.corr = 1;  # correct non-response
            else:
               key_resp_19.corr = 0;  # failed to respond (incorrectly)
        # store data for trials_8 (TrialHandler)
        trials_8.addData('key_resp_19.keys',key_resp_19.keys)
        trials_8.addData('key_resp_19.corr', key_resp_19.corr)
        if key_resp_19.keys != None:  # we had a response
            trials_8.addData('key_resp_19.rt', key_resp_19.rt)
            trials_8.addData('key_resp_19.duration', key_resp_19.duration)
        # the Routine "Task16" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Judge16" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Judge16.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_9
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        if key_resp_19.corr==1:
            feedback = '√'
            server_socket.sendall((str(correctTask1)).encode('utf-8')+ b'\n')
        else:
            feedback = '×'
            server_socket.sendall((str(wrongTask1)).encode('utf-8')+ b'\n')
        text_131.setColor(color, colorSpace='rgb')
        text_131.setText(word)
        text_132.setText(feedback)
        # keep track of which components have finished
        Judge16Components = [text_125, text_126, text_127, text_128, text_129, text_130, text_131, text_132]
        for thisComponent in Judge16Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Judge16" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_125* updates
            
            # if text_125 is starting this frame...
            if text_125.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_125.frameNStart = frameN  # exact frame index
                text_125.tStart = t  # local t and not account for scr refresh
                text_125.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_125, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_125.started')
                # update status
                text_125.status = STARTED
                text_125.setAutoDraw(True)
            
            # if text_125 is active this frame...
            if text_125.status == STARTED:
                # update params
                pass
            
            # if text_125 is stopping this frame...
            if text_125.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_125.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_125.tStop = t  # not accounting for scr refresh
                    text_125.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_125.stopped')
                    # update status
                    text_125.status = FINISHED
                    text_125.setAutoDraw(False)
            
            # *text_126* updates
            
            # if text_126 is starting this frame...
            if text_126.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_126.frameNStart = frameN  # exact frame index
                text_126.tStart = t  # local t and not account for scr refresh
                text_126.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_126, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_126.started')
                # update status
                text_126.status = STARTED
                text_126.setAutoDraw(True)
            
            # if text_126 is active this frame...
            if text_126.status == STARTED:
                # update params
                pass
            
            # if text_126 is stopping this frame...
            if text_126.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_126.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_126.tStop = t  # not accounting for scr refresh
                    text_126.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_126.stopped')
                    # update status
                    text_126.status = FINISHED
                    text_126.setAutoDraw(False)
            
            # *text_127* updates
            
            # if text_127 is starting this frame...
            if text_127.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_127.frameNStart = frameN  # exact frame index
                text_127.tStart = t  # local t and not account for scr refresh
                text_127.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_127, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_127.started')
                # update status
                text_127.status = STARTED
                text_127.setAutoDraw(True)
            
            # if text_127 is active this frame...
            if text_127.status == STARTED:
                # update params
                pass
            
            # if text_127 is stopping this frame...
            if text_127.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_127.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_127.tStop = t  # not accounting for scr refresh
                    text_127.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_127.stopped')
                    # update status
                    text_127.status = FINISHED
                    text_127.setAutoDraw(False)
            
            # *text_128* updates
            
            # if text_128 is starting this frame...
            if text_128.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_128.frameNStart = frameN  # exact frame index
                text_128.tStart = t  # local t and not account for scr refresh
                text_128.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_128, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_128.started')
                # update status
                text_128.status = STARTED
                text_128.setAutoDraw(True)
            
            # if text_128 is active this frame...
            if text_128.status == STARTED:
                # update params
                pass
            
            # if text_128 is stopping this frame...
            if text_128.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_128.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_128.tStop = t  # not accounting for scr refresh
                    text_128.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_128.stopped')
                    # update status
                    text_128.status = FINISHED
                    text_128.setAutoDraw(False)
            
            # *text_129* updates
            
            # if text_129 is starting this frame...
            if text_129.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_129.frameNStart = frameN  # exact frame index
                text_129.tStart = t  # local t and not account for scr refresh
                text_129.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_129, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_129.started')
                # update status
                text_129.status = STARTED
                text_129.setAutoDraw(True)
            
            # if text_129 is active this frame...
            if text_129.status == STARTED:
                # update params
                pass
            
            # if text_129 is stopping this frame...
            if text_129.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_129.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_129.tStop = t  # not accounting for scr refresh
                    text_129.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_129.stopped')
                    # update status
                    text_129.status = FINISHED
                    text_129.setAutoDraw(False)
            
            # *text_130* updates
            
            # if text_130 is starting this frame...
            if text_130.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_130.frameNStart = frameN  # exact frame index
                text_130.tStart = t  # local t and not account for scr refresh
                text_130.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_130, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_130.started')
                # update status
                text_130.status = STARTED
                text_130.setAutoDraw(True)
            
            # if text_130 is active this frame...
            if text_130.status == STARTED:
                # update params
                pass
            
            # if text_130 is stopping this frame...
            if text_130.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_130.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_130.tStop = t  # not accounting for scr refresh
                    text_130.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_130.stopped')
                    # update status
                    text_130.status = FINISHED
                    text_130.setAutoDraw(False)
            
            # *text_131* updates
            
            # if text_131 is starting this frame...
            if text_131.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_131.frameNStart = frameN  # exact frame index
                text_131.tStart = t  # local t and not account for scr refresh
                text_131.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_131, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_131.started')
                # update status
                text_131.status = STARTED
                text_131.setAutoDraw(True)
            
            # if text_131 is active this frame...
            if text_131.status == STARTED:
                # update params
                pass
            
            # if text_131 is stopping this frame...
            if text_131.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_131.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_131.tStop = t  # not accounting for scr refresh
                    text_131.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_131.stopped')
                    # update status
                    text_131.status = FINISHED
                    text_131.setAutoDraw(False)
            
            # *text_132* updates
            
            # if text_132 is starting this frame...
            if text_132.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_132.frameNStart = frameN  # exact frame index
                text_132.tStart = t  # local t and not account for scr refresh
                text_132.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_132, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_132.started')
                # update status
                text_132.status = STARTED
                text_132.setAutoDraw(True)
            
            # if text_132 is active this frame...
            if text_132.status == STARTED:
                # update params
                pass
            
            # if text_132 is stopping this frame...
            if text_132.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_132.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_132.tStop = t  # not accounting for scr refresh
                    text_132.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_132.stopped')
                    # update status
                    text_132.status = FINISHED
                    text_132.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Judge16Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Judge16" ---
        for thisComponent in Judge16Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Judge16.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_8'
    
    
    # --- Prepare to start Routine "Instruction17" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Instruction17.started', globalClock.getTime())
    key_resp_14.keys = []
    key_resp_14.rt = []
    _key_resp_14_allKeys = []
    # keep track of which components have finished
    Instruction17Components = [text_52, text_53, text_54, text_55, text_56, text_57, text_58, key_resp_14]
    for thisComponent in Instruction17Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instruction17" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_52* updates
        
        # if text_52 is starting this frame...
        if text_52.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_52.frameNStart = frameN  # exact frame index
            text_52.tStart = t  # local t and not account for scr refresh
            text_52.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_52, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_52.started')
            # update status
            text_52.status = STARTED
            text_52.setAutoDraw(True)
        
        # if text_52 is active this frame...
        if text_52.status == STARTED:
            # update params
            pass
        
        # *text_53* updates
        
        # if text_53 is starting this frame...
        if text_53.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_53.frameNStart = frameN  # exact frame index
            text_53.tStart = t  # local t and not account for scr refresh
            text_53.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_53, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_53.started')
            # update status
            text_53.status = STARTED
            text_53.setAutoDraw(True)
        
        # if text_53 is active this frame...
        if text_53.status == STARTED:
            # update params
            pass
        
        # *text_54* updates
        
        # if text_54 is starting this frame...
        if text_54.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_54.frameNStart = frameN  # exact frame index
            text_54.tStart = t  # local t and not account for scr refresh
            text_54.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_54, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_54.started')
            # update status
            text_54.status = STARTED
            text_54.setAutoDraw(True)
        
        # if text_54 is active this frame...
        if text_54.status == STARTED:
            # update params
            pass
        
        # *text_55* updates
        
        # if text_55 is starting this frame...
        if text_55.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_55.frameNStart = frameN  # exact frame index
            text_55.tStart = t  # local t and not account for scr refresh
            text_55.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_55, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_55.started')
            # update status
            text_55.status = STARTED
            text_55.setAutoDraw(True)
        
        # if text_55 is active this frame...
        if text_55.status == STARTED:
            # update params
            pass
        
        # *text_56* updates
        
        # if text_56 is starting this frame...
        if text_56.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_56.frameNStart = frameN  # exact frame index
            text_56.tStart = t  # local t and not account for scr refresh
            text_56.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_56, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_56.started')
            # update status
            text_56.status = STARTED
            text_56.setAutoDraw(True)
        
        # if text_56 is active this frame...
        if text_56.status == STARTED:
            # update params
            pass
        
        # *text_57* updates
        
        # if text_57 is starting this frame...
        if text_57.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_57.frameNStart = frameN  # exact frame index
            text_57.tStart = t  # local t and not account for scr refresh
            text_57.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_57, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_57.started')
            # update status
            text_57.status = STARTED
            text_57.setAutoDraw(True)
        
        # if text_57 is active this frame...
        if text_57.status == STARTED:
            # update params
            pass
        
        # *text_58* updates
        
        # if text_58 is starting this frame...
        if text_58.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_58.frameNStart = frameN  # exact frame index
            text_58.tStart = t  # local t and not account for scr refresh
            text_58.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_58, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_58.started')
            # update status
            text_58.status = STARTED
            text_58.setAutoDraw(True)
        
        # if text_58 is active this frame...
        if text_58.status == STARTED:
            # update params
            pass
        
        # *key_resp_14* updates
        waitOnFlip = False
        
        # if key_resp_14 is starting this frame...
        if key_resp_14.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_14.frameNStart = frameN  # exact frame index
            key_resp_14.tStart = t  # local t and not account for scr refresh
            key_resp_14.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_14, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_14.started')
            # update status
            key_resp_14.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_14.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_14.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_14.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_14.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_14_allKeys.extend(theseKeys)
            if len(_key_resp_14_allKeys):
                key_resp_14.keys = _key_resp_14_allKeys[-1].name  # just the last key pressed
                key_resp_14.rt = _key_resp_14_allKeys[-1].rt
                key_resp_14.duration = _key_resp_14_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Instruction17Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instruction17" ---
    for thisComponent in Instruction17Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Instruction17.stopped', globalClock.getTime())
    # check responses
    if key_resp_14.keys in ['', [], None]:  # No response was made
        key_resp_14.keys = None
    thisExp.addData('key_resp_14.keys',key_resp_14.keys)
    if key_resp_14.keys != None:  # we had a response
        thisExp.addData('key_resp_14.rt', key_resp_14.rt)
        thisExp.addData('key_resp_14.duration', key_resp_14.duration)
    thisExp.nextEntry()
    # the Routine "Instruction17" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_9 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Task16-17.xlsx'),
        seed=None, name='trials_9')
    thisExp.addLoop(trials_9)  # add the loop to the experiment
    thisTrial_9 = trials_9.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_9.rgb)
    if thisTrial_9 != None:
        for paramName in thisTrial_9:
            globals()[paramName] = thisTrial_9[paramName]
    
    for thisTrial_9 in trials_9:
        currentLoop = trials_9
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_9.rgb)
        if thisTrial_9 != None:
            for paramName in thisTrial_9:
                globals()[paramName] = thisTrial_9[paramName]
        
        # --- Prepare to start Routine "Task17" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Task17.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_21
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        server_socket.sendall((str(MarkNumber)).encode('utf-8')+ b'\n')
        
        text_94.setColor(color, colorSpace='rgb')
        text_94.setText(word)
        key_resp_20.keys = []
        key_resp_20.rt = []
        _key_resp_20_allKeys = []
        # keep track of which components have finished
        Task17Components = [text_88, text_89, text_90, text_91, text_92, text_93, text_94, key_resp_20]
        for thisComponent in Task17Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Task17" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_88* updates
            
            # if text_88 is starting this frame...
            if text_88.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_88.frameNStart = frameN  # exact frame index
                text_88.tStart = t  # local t and not account for scr refresh
                text_88.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_88, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_88.started')
                # update status
                text_88.status = STARTED
                text_88.setAutoDraw(True)
            
            # if text_88 is active this frame...
            if text_88.status == STARTED:
                # update params
                pass
            
            # *text_89* updates
            
            # if text_89 is starting this frame...
            if text_89.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_89.frameNStart = frameN  # exact frame index
                text_89.tStart = t  # local t and not account for scr refresh
                text_89.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_89, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_89.started')
                # update status
                text_89.status = STARTED
                text_89.setAutoDraw(True)
            
            # if text_89 is active this frame...
            if text_89.status == STARTED:
                # update params
                pass
            
            # *text_90* updates
            
            # if text_90 is starting this frame...
            if text_90.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_90.frameNStart = frameN  # exact frame index
                text_90.tStart = t  # local t and not account for scr refresh
                text_90.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_90, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_90.started')
                # update status
                text_90.status = STARTED
                text_90.setAutoDraw(True)
            
            # if text_90 is active this frame...
            if text_90.status == STARTED:
                # update params
                pass
            
            # *text_91* updates
            
            # if text_91 is starting this frame...
            if text_91.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_91.frameNStart = frameN  # exact frame index
                text_91.tStart = t  # local t and not account for scr refresh
                text_91.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_91, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_91.started')
                # update status
                text_91.status = STARTED
                text_91.setAutoDraw(True)
            
            # if text_91 is active this frame...
            if text_91.status == STARTED:
                # update params
                pass
            
            # *text_92* updates
            
            # if text_92 is starting this frame...
            if text_92.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_92.frameNStart = frameN  # exact frame index
                text_92.tStart = t  # local t and not account for scr refresh
                text_92.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_92, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_92.started')
                # update status
                text_92.status = STARTED
                text_92.setAutoDraw(True)
            
            # if text_92 is active this frame...
            if text_92.status == STARTED:
                # update params
                pass
            
            # *text_93* updates
            
            # if text_93 is starting this frame...
            if text_93.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_93.frameNStart = frameN  # exact frame index
                text_93.tStart = t  # local t and not account for scr refresh
                text_93.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_93, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_93.started')
                # update status
                text_93.status = STARTED
                text_93.setAutoDraw(True)
            
            # if text_93 is active this frame...
            if text_93.status == STARTED:
                # update params
                pass
            
            # *text_94* updates
            
            # if text_94 is starting this frame...
            if text_94.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_94.frameNStart = frameN  # exact frame index
                text_94.tStart = t  # local t and not account for scr refresh
                text_94.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_94, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_94.started')
                # update status
                text_94.status = STARTED
                text_94.setAutoDraw(True)
            
            # if text_94 is active this frame...
            if text_94.status == STARTED:
                # update params
                pass
            
            # *key_resp_20* updates
            waitOnFlip = False
            
            # if key_resp_20 is starting this frame...
            if key_resp_20.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_20.frameNStart = frameN  # exact frame index
                key_resp_20.tStart = t  # local t and not account for scr refresh
                key_resp_20.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_20, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_20.started')
                # update status
                key_resp_20.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_20.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_20.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_20.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_20.getKeys(keyList=['e','i'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_20_allKeys.extend(theseKeys)
                if len(_key_resp_20_allKeys):
                    key_resp_20.keys = _key_resp_20_allKeys[-1].name  # just the last key pressed
                    key_resp_20.rt = _key_resp_20_allKeys[-1].rt
                    key_resp_20.duration = _key_resp_20_allKeys[-1].duration
                    # was this correct?
                    if (key_resp_20.keys == str(answer)) or (key_resp_20.keys == answer):
                        key_resp_20.corr = 1
                    else:
                        key_resp_20.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Task17Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Task17" ---
        for thisComponent in Task17Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Task17.stopped', globalClock.getTime())
        # check responses
        if key_resp_20.keys in ['', [], None]:  # No response was made
            key_resp_20.keys = None
            # was no response the correct answer?!
            if str(answer).lower() == 'none':
               key_resp_20.corr = 1;  # correct non-response
            else:
               key_resp_20.corr = 0;  # failed to respond (incorrectly)
        # store data for trials_9 (TrialHandler)
        trials_9.addData('key_resp_20.keys',key_resp_20.keys)
        trials_9.addData('key_resp_20.corr', key_resp_20.corr)
        if key_resp_20.keys != None:  # we had a response
            trials_9.addData('key_resp_20.rt', key_resp_20.rt)
            trials_9.addData('key_resp_20.duration', key_resp_20.duration)
        # the Routine "Task17" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Judge17" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Judge17.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_10
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        if key_resp_20.corr==1:
            feedback = '√'
            server_socket.sendall((str(correctTask1)).encode('utf-8')+ b'\n')
        else:
            feedback = '×'
            server_socket.sendall((str(wrongTask1)).encode('utf-8')+ b'\n')
        text_139.setColor(color, colorSpace='rgb')
        text_139.setText(word)
        text_140.setText(feedback)
        # keep track of which components have finished
        Judge17Components = [text_133, text_134, text_135, text_136, text_137, text_138, text_139, text_140]
        for thisComponent in Judge17Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Judge17" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_133* updates
            
            # if text_133 is starting this frame...
            if text_133.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_133.frameNStart = frameN  # exact frame index
                text_133.tStart = t  # local t and not account for scr refresh
                text_133.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_133, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_133.started')
                # update status
                text_133.status = STARTED
                text_133.setAutoDraw(True)
            
            # if text_133 is active this frame...
            if text_133.status == STARTED:
                # update params
                pass
            
            # if text_133 is stopping this frame...
            if text_133.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_133.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_133.tStop = t  # not accounting for scr refresh
                    text_133.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_133.stopped')
                    # update status
                    text_133.status = FINISHED
                    text_133.setAutoDraw(False)
            
            # *text_134* updates
            
            # if text_134 is starting this frame...
            if text_134.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_134.frameNStart = frameN  # exact frame index
                text_134.tStart = t  # local t and not account for scr refresh
                text_134.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_134, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_134.started')
                # update status
                text_134.status = STARTED
                text_134.setAutoDraw(True)
            
            # if text_134 is active this frame...
            if text_134.status == STARTED:
                # update params
                pass
            
            # if text_134 is stopping this frame...
            if text_134.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_134.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_134.tStop = t  # not accounting for scr refresh
                    text_134.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_134.stopped')
                    # update status
                    text_134.status = FINISHED
                    text_134.setAutoDraw(False)
            
            # *text_135* updates
            
            # if text_135 is starting this frame...
            if text_135.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_135.frameNStart = frameN  # exact frame index
                text_135.tStart = t  # local t and not account for scr refresh
                text_135.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_135, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_135.started')
                # update status
                text_135.status = STARTED
                text_135.setAutoDraw(True)
            
            # if text_135 is active this frame...
            if text_135.status == STARTED:
                # update params
                pass
            
            # if text_135 is stopping this frame...
            if text_135.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_135.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_135.tStop = t  # not accounting for scr refresh
                    text_135.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_135.stopped')
                    # update status
                    text_135.status = FINISHED
                    text_135.setAutoDraw(False)
            
            # *text_136* updates
            
            # if text_136 is starting this frame...
            if text_136.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_136.frameNStart = frameN  # exact frame index
                text_136.tStart = t  # local t and not account for scr refresh
                text_136.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_136, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_136.started')
                # update status
                text_136.status = STARTED
                text_136.setAutoDraw(True)
            
            # if text_136 is active this frame...
            if text_136.status == STARTED:
                # update params
                pass
            
            # if text_136 is stopping this frame...
            if text_136.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_136.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_136.tStop = t  # not accounting for scr refresh
                    text_136.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_136.stopped')
                    # update status
                    text_136.status = FINISHED
                    text_136.setAutoDraw(False)
            
            # *text_137* updates
            
            # if text_137 is starting this frame...
            if text_137.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_137.frameNStart = frameN  # exact frame index
                text_137.tStart = t  # local t and not account for scr refresh
                text_137.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_137, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_137.started')
                # update status
                text_137.status = STARTED
                text_137.setAutoDraw(True)
            
            # if text_137 is active this frame...
            if text_137.status == STARTED:
                # update params
                pass
            
            # if text_137 is stopping this frame...
            if text_137.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_137.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_137.tStop = t  # not accounting for scr refresh
                    text_137.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_137.stopped')
                    # update status
                    text_137.status = FINISHED
                    text_137.setAutoDraw(False)
            
            # *text_138* updates
            
            # if text_138 is starting this frame...
            if text_138.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_138.frameNStart = frameN  # exact frame index
                text_138.tStart = t  # local t and not account for scr refresh
                text_138.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_138, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_138.started')
                # update status
                text_138.status = STARTED
                text_138.setAutoDraw(True)
            
            # if text_138 is active this frame...
            if text_138.status == STARTED:
                # update params
                pass
            
            # if text_138 is stopping this frame...
            if text_138.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_138.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_138.tStop = t  # not accounting for scr refresh
                    text_138.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_138.stopped')
                    # update status
                    text_138.status = FINISHED
                    text_138.setAutoDraw(False)
            
            # *text_139* updates
            
            # if text_139 is starting this frame...
            if text_139.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_139.frameNStart = frameN  # exact frame index
                text_139.tStart = t  # local t and not account for scr refresh
                text_139.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_139, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_139.started')
                # update status
                text_139.status = STARTED
                text_139.setAutoDraw(True)
            
            # if text_139 is active this frame...
            if text_139.status == STARTED:
                # update params
                pass
            
            # if text_139 is stopping this frame...
            if text_139.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_139.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_139.tStop = t  # not accounting for scr refresh
                    text_139.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_139.stopped')
                    # update status
                    text_139.status = FINISHED
                    text_139.setAutoDraw(False)
            
            # *text_140* updates
            
            # if text_140 is starting this frame...
            if text_140.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_140.frameNStart = frameN  # exact frame index
                text_140.tStart = t  # local t and not account for scr refresh
                text_140.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_140, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_140.started')
                # update status
                text_140.status = STARTED
                text_140.setAutoDraw(True)
            
            # if text_140 is active this frame...
            if text_140.status == STARTED:
                # update params
                pass
            
            # if text_140 is stopping this frame...
            if text_140.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_140.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_140.tStop = t  # not accounting for scr refresh
                    text_140.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_140.stopped')
                    # update status
                    text_140.status = FINISHED
                    text_140.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Judge17Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Judge17" ---
        for thisComponent in Judge17Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Judge17.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_9'
    
    
    # --- Prepare to start Routine "Task1Over" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Task1Over.started', globalClock.getTime())
    key_.keys = []
    key_.rt = []
    _key__allKeys = []
    # keep track of which components have finished
    Task1OverComponents = [text1, key_]
    for thisComponent in Task1OverComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Task1Over" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text1* updates
        
        # if text1 is starting this frame...
        if text1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text1.frameNStart = frameN  # exact frame index
            text1.tStart = t  # local t and not account for scr refresh
            text1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text1.started')
            # update status
            text1.status = STARTED
            text1.setAutoDraw(True)
        
        # if text1 is active this frame...
        if text1.status == STARTED:
            # update params
            pass
        
        # *key_* updates
        waitOnFlip = False
        
        # if key_ is starting this frame...
        if key_.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_.frameNStart = frameN  # exact frame index
            key_.tStart = t  # local t and not account for scr refresh
            key_.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_.started')
            # update status
            key_.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_.status == STARTED and not waitOnFlip:
            theseKeys = key_.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key__allKeys.extend(theseKeys)
            if len(_key__allKeys):
                key_.keys = _key__allKeys[-1].name  # just the last key pressed
                key_.rt = _key__allKeys[-1].rt
                key_.duration = _key__allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Task1OverComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Task1Over" ---
    for thisComponent in Task1OverComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Task1Over.stopped', globalClock.getTime())
    # check responses
    if key_.keys in ['', [], None]:  # No response was made
        key_.keys = None
    thisExp.addData('key_.keys',key_.keys)
    if key_.keys != None:  # we had a response
        thisExp.addData('key_.rt', key_.rt)
        thisExp.addData('key_.duration', key_.duration)
    thisExp.nextEntry()
    # the Routine "Task1Over" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "OpeningEyes" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('OpeningEyes.started', globalClock.getTime())
    # keep track of which components have finished
    OpeningEyesComponents = [text]
    for thisComponent in OpeningEyesComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "OpeningEyes" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 2.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        
        # if text is starting this frame...
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text.started')
            # update status
            text.status = STARTED
            text.setAutoDraw(True)
        
        # if text is active this frame...
        if text.status == STARTED:
            # update params
            pass
        
        # if text is stopping this frame...
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.stopped')
                # update status
                text.status = FINISHED
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in OpeningEyesComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "OpeningEyes" ---
    for thisComponent in OpeningEyesComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('OpeningEyes.stopped', globalClock.getTime())
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-2.000000)
    
    # --- Prepare to start Routine "openingEyes1" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('openingEyes1.started', globalClock.getTime())
    # Run 'Begin Routine' code from code_26
    datastamp=int(datetime.now().timestamp()*1000)-timebegin
    server_socket.sendall((str(startOpeningEyes)).encode('utf-8')+ b'\n')
    # keep track of which components have finished
    openingEyes1Components = [text_147]
    for thisComponent in openingEyes1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "openingEyes1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 90.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_147* updates
        
        # if text_147 is starting this frame...
        if text_147.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_147.frameNStart = frameN  # exact frame index
            text_147.tStart = t  # local t and not account for scr refresh
            text_147.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_147, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_147.started')
            # update status
            text_147.status = STARTED
            text_147.setAutoDraw(True)
        
        # if text_147 is active this frame...
        if text_147.status == STARTED:
            # update params
            pass
        
        # if text_147 is stopping this frame...
        if text_147.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_147.tStartRefresh + 90-frameTolerance:
                # keep track of stop time/frame for later
                text_147.tStop = t  # not accounting for scr refresh
                text_147.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_147.stopped')
                # update status
                text_147.status = FINISHED
                text_147.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in openingEyes1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "openingEyes1" ---
    for thisComponent in openingEyes1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('openingEyes1.stopped', globalClock.getTime())
    # Run 'End Routine' code from code_26
    server_socket.sendall((str(endOpeningEyes)).encode('utf-8')+ b'\n')
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-90.000000)
    
    # --- Prepare to start Routine "Transition2" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Transition2.started', globalClock.getTime())
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    # keep track of which components have finished
    Transition2Components = [image, text_7, text_8, key_resp, text_28]
    for thisComponent in Transition2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Transition2" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image* updates
        
        # if image is starting this frame...
        if image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image.frameNStart = frameN  # exact frame index
            image.tStart = t  # local t and not account for scr refresh
            image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image.started')
            # update status
            image.status = STARTED
            image.setAutoDraw(True)
        
        # if image is active this frame...
        if image.status == STARTED:
            # update params
            pass
        
        # if image is stopping this frame...
        if image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > image.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                image.tStop = t  # not accounting for scr refresh
                image.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image.stopped')
                # update status
                image.status = FINISHED
                image.setAutoDraw(False)
        
        # *text_7* updates
        
        # if text_7 is starting this frame...
        if text_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_7.frameNStart = frameN  # exact frame index
            text_7.tStart = t  # local t and not account for scr refresh
            text_7.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_7, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_7.started')
            # update status
            text_7.status = STARTED
            text_7.setAutoDraw(True)
        
        # if text_7 is active this frame...
        if text_7.status == STARTED:
            # update params
            pass
        
        # if text_7 is stopping this frame...
        if text_7.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_7.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text_7.tStop = t  # not accounting for scr refresh
                text_7.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_7.stopped')
                # update status
                text_7.status = FINISHED
                text_7.setAutoDraw(False)
        
        # *text_8* updates
        
        # if text_8 is starting this frame...
        if text_8.status == NOT_STARTED and tThisFlip >= 2.0-frameTolerance:
            # keep track of start time/frame for later
            text_8.frameNStart = frameN  # exact frame index
            text_8.tStart = t  # local t and not account for scr refresh
            text_8.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_8, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_8.started')
            # update status
            text_8.status = STARTED
            text_8.setAutoDraw(True)
        
        # if text_8 is active this frame...
        if text_8.status == STARTED:
            # update params
            pass
        
        # *key_resp* updates
        waitOnFlip = False
        
        # if key_resp is starting this frame...
        if key_resp.status == NOT_STARTED and tThisFlip >= 2.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp.started')
            # update status
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                key_resp.rt = _key_resp_allKeys[-1].rt
                key_resp.duration = _key_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # *text_28* updates
        
        # if text_28 is starting this frame...
        if text_28.status == NOT_STARTED and tThisFlip >= 2.0-frameTolerance:
            # keep track of start time/frame for later
            text_28.frameNStart = frameN  # exact frame index
            text_28.tStart = t  # local t and not account for scr refresh
            text_28.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_28, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_28.started')
            # update status
            text_28.status = STARTED
            text_28.setAutoDraw(True)
        
        # if text_28 is active this frame...
        if text_28.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Transition2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Transition2" ---
    for thisComponent in Transition2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Transition2.stopped', globalClock.getTime())
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    thisExp.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        thisExp.addData('key_resp.rt', key_resp.rt)
        thisExp.addData('key_resp.duration', key_resp.duration)
    thisExp.nextEntry()
    # the Routine "Transition2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Task2GetReady" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Task2GetReady.started', globalClock.getTime())
    # keep track of which components have finished
    Task2GetReadyComponents = [text_15]
    for thisComponent in Task2GetReadyComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Task2GetReady" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 2.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_15* updates
        
        # if text_15 is starting this frame...
        if text_15.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_15.frameNStart = frameN  # exact frame index
            text_15.tStart = t  # local t and not account for scr refresh
            text_15.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_15, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_15.started')
            # update status
            text_15.status = STARTED
            text_15.setAutoDraw(True)
        
        # if text_15 is active this frame...
        if text_15.status == STARTED:
            # update params
            pass
        
        # if text_15 is stopping this frame...
        if text_15.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_15.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text_15.tStop = t  # not accounting for scr refresh
                text_15.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_15.stopped')
                # update status
                text_15.status = FINISHED
                text_15.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Task2GetReadyComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Task2GetReady" ---
    for thisComponent in Task2GetReadyComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Task2GetReady.stopped', globalClock.getTime())
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-2.000000)
    
    # set up handler to look after randomisation of conditions etc
    trials = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Task2.xlsx'),
        seed=None, name='trials')
    thisExp.addLoop(trials)  # add the loop to the experiment
    thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            globals()[paramName] = thisTrial[paramName]
    
    for thisTrial in trials:
        currentLoop = trials
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                globals()[paramName] = thisTrial[paramName]
        
        # --- Prepare to start Routine "Task2" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Task2.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_22
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        server_socket.sendall((str(MarkNumber)).encode('utf-8')+ b'\n')
        
        text_18.setColor(color, colorSpace='rgb')
        text_18.setText(word)
        key_resp_6.keys = []
        key_resp_6.rt = []
        _key_resp_6_allKeys = []
        # keep track of which components have finished
        Task2Components = [text_16, text_17, text_18, key_resp_6]
        for thisComponent in Task2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Task2" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_16* updates
            
            # if text_16 is starting this frame...
            if text_16.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_16.frameNStart = frameN  # exact frame index
                text_16.tStart = t  # local t and not account for scr refresh
                text_16.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_16, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_16.started')
                # update status
                text_16.status = STARTED
                text_16.setAutoDraw(True)
            
            # if text_16 is active this frame...
            if text_16.status == STARTED:
                # update params
                pass
            
            # *text_17* updates
            
            # if text_17 is starting this frame...
            if text_17.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_17.frameNStart = frameN  # exact frame index
                text_17.tStart = t  # local t and not account for scr refresh
                text_17.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_17, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_17.started')
                # update status
                text_17.status = STARTED
                text_17.setAutoDraw(True)
            
            # if text_17 is active this frame...
            if text_17.status == STARTED:
                # update params
                pass
            
            # *text_18* updates
            
            # if text_18 is starting this frame...
            if text_18.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_18.frameNStart = frameN  # exact frame index
                text_18.tStart = t  # local t and not account for scr refresh
                text_18.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_18, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_18.started')
                # update status
                text_18.status = STARTED
                text_18.setAutoDraw(True)
            
            # if text_18 is active this frame...
            if text_18.status == STARTED:
                # update params
                pass
            
            # *key_resp_6* updates
            waitOnFlip = False
            
            # if key_resp_6 is starting this frame...
            if key_resp_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_6.frameNStart = frameN  # exact frame index
                key_resp_6.tStart = t  # local t and not account for scr refresh
                key_resp_6.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_6, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_6.started')
                # update status
                key_resp_6.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_6.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_6.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_6.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_6.getKeys(keyList=['e','i'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_6_allKeys.extend(theseKeys)
                if len(_key_resp_6_allKeys):
                    key_resp_6.keys = _key_resp_6_allKeys[-1].name  # just the last key pressed
                    key_resp_6.rt = _key_resp_6_allKeys[-1].rt
                    key_resp_6.duration = _key_resp_6_allKeys[-1].duration
                    # was this correct?
                    if (key_resp_6.keys == str(answer)) or (key_resp_6.keys == answer):
                        key_resp_6.corr = 1
                    else:
                        key_resp_6.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Task2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Task2" ---
        for thisComponent in Task2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Task2.stopped', globalClock.getTime())
        # check responses
        if key_resp_6.keys in ['', [], None]:  # No response was made
            key_resp_6.keys = None
            # was no response the correct answer?!
            if str(answer).lower() == 'none':
               key_resp_6.corr = 1;  # correct non-response
            else:
               key_resp_6.corr = 0;  # failed to respond (incorrectly)
        # store data for trials (TrialHandler)
        trials.addData('key_resp_6.keys',key_resp_6.keys)
        trials.addData('key_resp_6.corr', key_resp_6.corr)
        if key_resp_6.keys != None:  # we had a response
            trials.addData('key_resp_6.rt', key_resp_6.rt)
            trials.addData('key_resp_6.duration', key_resp_6.duration)
        # the Routine "Task2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Judge18" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Judge18.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_11
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        if key_resp_6.corr==1:
            feedback = '√'
            server_socket.sendall((str(correctTask2)).encode('utf-8')+ b'\n')
        else:
            feedback = '×'
            server_socket.sendall((str(wrongTask2)).encode('utf-8')+ b'\n')
        text_143.setColor(color, colorSpace='rgb')
        text_143.setText(word)
        text_144.setText(feedback)
        # keep track of which components have finished
        Judge18Components = [text_141, text_142, text_143, text_144]
        for thisComponent in Judge18Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Judge18" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_141* updates
            
            # if text_141 is starting this frame...
            if text_141.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_141.frameNStart = frameN  # exact frame index
                text_141.tStart = t  # local t and not account for scr refresh
                text_141.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_141, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_141.started')
                # update status
                text_141.status = STARTED
                text_141.setAutoDraw(True)
            
            # if text_141 is active this frame...
            if text_141.status == STARTED:
                # update params
                pass
            
            # if text_141 is stopping this frame...
            if text_141.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_141.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_141.tStop = t  # not accounting for scr refresh
                    text_141.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_141.stopped')
                    # update status
                    text_141.status = FINISHED
                    text_141.setAutoDraw(False)
            
            # *text_142* updates
            
            # if text_142 is starting this frame...
            if text_142.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_142.frameNStart = frameN  # exact frame index
                text_142.tStart = t  # local t and not account for scr refresh
                text_142.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_142, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_142.started')
                # update status
                text_142.status = STARTED
                text_142.setAutoDraw(True)
            
            # if text_142 is active this frame...
            if text_142.status == STARTED:
                # update params
                pass
            
            # if text_142 is stopping this frame...
            if text_142.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_142.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_142.tStop = t  # not accounting for scr refresh
                    text_142.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_142.stopped')
                    # update status
                    text_142.status = FINISHED
                    text_142.setAutoDraw(False)
            
            # *text_143* updates
            
            # if text_143 is starting this frame...
            if text_143.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_143.frameNStart = frameN  # exact frame index
                text_143.tStart = t  # local t and not account for scr refresh
                text_143.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_143, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_143.started')
                # update status
                text_143.status = STARTED
                text_143.setAutoDraw(True)
            
            # if text_143 is active this frame...
            if text_143.status == STARTED:
                # update params
                pass
            
            # if text_143 is stopping this frame...
            if text_143.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_143.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_143.tStop = t  # not accounting for scr refresh
                    text_143.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_143.stopped')
                    # update status
                    text_143.status = FINISHED
                    text_143.setAutoDraw(False)
            
            # *text_144* updates
            
            # if text_144 is starting this frame...
            if text_144.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_144.frameNStart = frameN  # exact frame index
                text_144.tStart = t  # local t and not account for scr refresh
                text_144.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_144, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_144.started')
                # update status
                text_144.status = STARTED
                text_144.setAutoDraw(True)
            
            # if text_144 is active this frame...
            if text_144.status == STARTED:
                # update params
                pass
            
            # if text_144 is stopping this frame...
            if text_144.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_144.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_144.tStop = t  # not accounting for scr refresh
                    text_144.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_144.stopped')
                    # update status
                    text_144.status = FINISHED
                    text_144.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Judge18Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Judge18" ---
        for thisComponent in Judge18Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Judge18.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials'
    
    
    # --- Prepare to start Routine "Task2Over" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Task2Over.started', globalClock.getTime())
    key_resp_3.keys = []
    key_resp_3.rt = []
    _key_resp_3_allKeys = []
    # keep track of which components have finished
    Task2OverComponents = [text_6, key_resp_3]
    for thisComponent in Task2OverComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Task2Over" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_6* updates
        
        # if text_6 is starting this frame...
        if text_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_6.frameNStart = frameN  # exact frame index
            text_6.tStart = t  # local t and not account for scr refresh
            text_6.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_6, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_6.started')
            # update status
            text_6.status = STARTED
            text_6.setAutoDraw(True)
        
        # if text_6 is active this frame...
        if text_6.status == STARTED:
            # update params
            pass
        
        # *key_resp_3* updates
        waitOnFlip = False
        
        # if key_resp_3 is starting this frame...
        if key_resp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_3.frameNStart = frameN  # exact frame index
            key_resp_3.tStart = t  # local t and not account for scr refresh
            key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_3.started')
            # update status
            key_resp_3.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_3.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_3.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_3_allKeys.extend(theseKeys)
            if len(_key_resp_3_allKeys):
                key_resp_3.keys = _key_resp_3_allKeys[-1].name  # just the last key pressed
                key_resp_3.rt = _key_resp_3_allKeys[-1].rt
                key_resp_3.duration = _key_resp_3_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Task2OverComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Task2Over" ---
    for thisComponent in Task2OverComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Task2Over.stopped', globalClock.getTime())
    # check responses
    if key_resp_3.keys in ['', [], None]:  # No response was made
        key_resp_3.keys = None
    thisExp.addData('key_resp_3.keys',key_resp_3.keys)
    if key_resp_3.keys != None:  # we had a response
        thisExp.addData('key_resp_3.rt', key_resp_3.rt)
        thisExp.addData('key_resp_3.duration', key_resp_3.duration)
    thisExp.nextEntry()
    # the Routine "Task2Over" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Transition3" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Transition3.started', globalClock.getTime())
    key_resp_4.keys = []
    key_resp_4.rt = []
    _key_resp_4_allKeys = []
    # keep track of which components have finished
    Transition3Components = [image_2, text_10, text_11, key_resp_4]
    for thisComponent in Transition3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Transition3" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image_2* updates
        
        # if image_2 is starting this frame...
        if image_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_2.frameNStart = frameN  # exact frame index
            image_2.tStart = t  # local t and not account for scr refresh
            image_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_2.started')
            # update status
            image_2.status = STARTED
            image_2.setAutoDraw(True)
        
        # if image_2 is active this frame...
        if image_2.status == STARTED:
            # update params
            pass
        
        # if image_2 is stopping this frame...
        if image_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > image_2.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                image_2.tStop = t  # not accounting for scr refresh
                image_2.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_2.stopped')
                # update status
                image_2.status = FINISHED
                image_2.setAutoDraw(False)
        
        # *text_10* updates
        
        # if text_10 is starting this frame...
        if text_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_10.frameNStart = frameN  # exact frame index
            text_10.tStart = t  # local t and not account for scr refresh
            text_10.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_10, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_10.started')
            # update status
            text_10.status = STARTED
            text_10.setAutoDraw(True)
        
        # if text_10 is active this frame...
        if text_10.status == STARTED:
            # update params
            pass
        
        # if text_10 is stopping this frame...
        if text_10.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_10.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text_10.tStop = t  # not accounting for scr refresh
                text_10.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_10.stopped')
                # update status
                text_10.status = FINISHED
                text_10.setAutoDraw(False)
        
        # *text_11* updates
        
        # if text_11 is starting this frame...
        if text_11.status == NOT_STARTED and tThisFlip >= 2.0-frameTolerance:
            # keep track of start time/frame for later
            text_11.frameNStart = frameN  # exact frame index
            text_11.tStart = t  # local t and not account for scr refresh
            text_11.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_11, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_11.started')
            # update status
            text_11.status = STARTED
            text_11.setAutoDraw(True)
        
        # if text_11 is active this frame...
        if text_11.status == STARTED:
            # update params
            pass
        
        # *key_resp_4* updates
        waitOnFlip = False
        
        # if key_resp_4 is starting this frame...
        if key_resp_4.status == NOT_STARTED and tThisFlip >= 2.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_4.frameNStart = frameN  # exact frame index
            key_resp_4.tStart = t  # local t and not account for scr refresh
            key_resp_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_4, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_4.started')
            # update status
            key_resp_4.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_4.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_4.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_4_allKeys.extend(theseKeys)
            if len(_key_resp_4_allKeys):
                key_resp_4.keys = _key_resp_4_allKeys[-1].name  # just the last key pressed
                key_resp_4.rt = _key_resp_4_allKeys[-1].rt
                key_resp_4.duration = _key_resp_4_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Transition3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Transition3" ---
    for thisComponent in Transition3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Transition3.stopped', globalClock.getTime())
    # check responses
    if key_resp_4.keys in ['', [], None]:  # No response was made
        key_resp_4.keys = None
    thisExp.addData('key_resp_4.keys',key_resp_4.keys)
    if key_resp_4.keys != None:  # we had a response
        thisExp.addData('key_resp_4.rt', key_resp_4.rt)
        thisExp.addData('key_resp_4.duration', key_resp_4.duration)
    thisExp.nextEntry()
    # the Routine "Transition3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Task3GetReady" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Task3GetReady.started', globalClock.getTime())
    # keep track of which components have finished
    Task3GetReadyComponents = [text_12, text_13]
    for thisComponent in Task3GetReadyComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Task3GetReady" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 4.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_12* updates
        
        # if text_12 is starting this frame...
        if text_12.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_12.frameNStart = frameN  # exact frame index
            text_12.tStart = t  # local t and not account for scr refresh
            text_12.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_12, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_12.started')
            # update status
            text_12.status = STARTED
            text_12.setAutoDraw(True)
        
        # if text_12 is active this frame...
        if text_12.status == STARTED:
            # update params
            pass
        
        # if text_12 is stopping this frame...
        if text_12.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_12.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text_12.tStop = t  # not accounting for scr refresh
                text_12.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_12.stopped')
                # update status
                text_12.status = FINISHED
                text_12.setAutoDraw(False)
        
        # *text_13* updates
        
        # if text_13 is starting this frame...
        if text_13.status == NOT_STARTED and tThisFlip >= 2.0-frameTolerance:
            # keep track of start time/frame for later
            text_13.frameNStart = frameN  # exact frame index
            text_13.tStart = t  # local t and not account for scr refresh
            text_13.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_13, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_13.started')
            # update status
            text_13.status = STARTED
            text_13.setAutoDraw(True)
        
        # if text_13 is active this frame...
        if text_13.status == STARTED:
            # update params
            pass
        
        # if text_13 is stopping this frame...
        if text_13.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_13.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                text_13.tStop = t  # not accounting for scr refresh
                text_13.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_13.stopped')
                # update status
                text_13.status = FINISHED
                text_13.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Task3GetReadyComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Task3GetReady" ---
    for thisComponent in Task3GetReadyComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Task3GetReady.stopped', globalClock.getTime())
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-4.000000)
    
    # set up handler to look after randomisation of conditions etc
    trials_3 = data.TrialHandler(nReps=80.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_3')
    thisExp.addLoop(trials_3)  # add the loop to the experiment
    thisTrial_3 = trials_3.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
    if thisTrial_3 != None:
        for paramName in thisTrial_3:
            globals()[paramName] = thisTrial_3[paramName]
    
    for thisTrial_3 in trials_3:
        currentLoop = trials_3
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
        if thisTrial_3 != None:
            for paramName in thisTrial_3:
                globals()[paramName] = thisTrial_3[paramName]
        
        # set up handler to look after randomisation of conditions etc
        trials_10 = data.TrialHandler(nReps=99.0, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trials_10')
        thisExp.addLoop(trials_10)  # add the loop to the experiment
        thisTrial_10 = trials_10.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_10.rgb)
        if thisTrial_10 != None:
            for paramName in thisTrial_10:
                globals()[paramName] = thisTrial_10[paramName]
        
        for thisTrial_10 in trials_10:
            currentLoop = trials_10
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_10.rgb)
            if thisTrial_10 != None:
                for paramName in thisTrial_10:
                    globals()[paramName] = thisTrial_10[paramName]
            
            # --- Prepare to start Routine "zhushidian" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('zhushidian.started', globalClock.getTime())
            # Run 'Begin Routine' code from code_4
            time = random.uniform(1.5,5.5)
            key_resp_15.keys = []
            key_resp_15.rt = []
            _key_resp_15_allKeys = []
            # keep track of which components have finished
            zhushidianComponents = [text_99, key_resp_15]
            for thisComponent in zhushidianComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "zhushidian" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_99* updates
                
                # if text_99 is starting this frame...
                if text_99.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_99.frameNStart = frameN  # exact frame index
                    text_99.tStart = t  # local t and not account for scr refresh
                    text_99.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_99, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_99.started')
                    # update status
                    text_99.status = STARTED
                    text_99.setAutoDraw(True)
                
                # if text_99 is active this frame...
                if text_99.status == STARTED:
                    # update params
                    pass
                
                # if text_99 is stopping this frame...
                if text_99.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > text_99.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        text_99.tStop = t  # not accounting for scr refresh
                        text_99.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'text_99.stopped')
                        # update status
                        text_99.status = FINISHED
                        text_99.setAutoDraw(False)
                
                # *key_resp_15* updates
                waitOnFlip = False
                
                # if key_resp_15 is starting this frame...
                if key_resp_15.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_15.frameNStart = frameN  # exact frame index
                    key_resp_15.tStart = t  # local t and not account for scr refresh
                    key_resp_15.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_15, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_15.started')
                    # update status
                    key_resp_15.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_15.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_15.clearEvents, eventType='keyboard')  # clear events on next screen flip
                
                # if key_resp_15 is stopping this frame...
                if key_resp_15.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > key_resp_15.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        key_resp_15.tStop = t  # not accounting for scr refresh
                        key_resp_15.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'key_resp_15.stopped')
                        # update status
                        key_resp_15.status = FINISHED
                        key_resp_15.status = FINISHED
                if key_resp_15.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_15.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_15_allKeys.extend(theseKeys)
                    if len(_key_resp_15_allKeys):
                        key_resp_15.keys = _key_resp_15_allKeys[-1].name  # just the last key pressed
                        key_resp_15.rt = _key_resp_15_allKeys[-1].rt
                        key_resp_15.duration = _key_resp_15_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in zhushidianComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "zhushidian" ---
            for thisComponent in zhushidianComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('zhushidian.stopped', globalClock.getTime())
            # check responses
            if key_resp_15.keys in ['', [], None]:  # No response was made
                key_resp_15.keys = None
            trials_10.addData('key_resp_15.keys',key_resp_15.keys)
            if key_resp_15.keys != None:  # we had a response
                trials_10.addData('key_resp_15.rt', key_resp_15.rt)
                trials_10.addData('key_resp_15.duration', key_resp_15.duration)
            # the Routine "zhushidian" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "TooEarly" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('TooEarly.started', globalClock.getTime())
            # Run 'Begin Routine' code from code_12
            time_Early=0
            datastamp=int(datetime.now().timestamp()*1000)-timebegin
            if key_resp_15.keys=='space':
                time_Early=1
                server_socket.sendall((str(tooearly)).encode('utf-8')+ b'\n')
            else:
                trials_10.finished=True
            # keep track of which components have finished
            TooEarlyComponents = [text_145]
            for thisComponent in TooEarlyComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "TooEarly" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_145* updates
                
                # if text_145 is starting this frame...
                if text_145.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_145.frameNStart = frameN  # exact frame index
                    text_145.tStart = t  # local t and not account for scr refresh
                    text_145.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_145, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_145.started')
                    # update status
                    text_145.status = STARTED
                    text_145.setAutoDraw(True)
                
                # if text_145 is active this frame...
                if text_145.status == STARTED:
                    # update params
                    pass
                
                # if text_145 is stopping this frame...
                if text_145.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > text_145.tStartRefresh + time_Early-frameTolerance:
                        # keep track of stop time/frame for later
                        text_145.tStop = t  # not accounting for scr refresh
                        text_145.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'text_145.stopped')
                        # update status
                        text_145.status = FINISHED
                        text_145.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in TooEarlyComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "TooEarly" ---
            for thisComponent in TooEarlyComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('TooEarly.stopped', globalClock.getTime())
            # the Routine "TooEarly" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed 99.0 repeats of 'trials_10'
        
        
        # --- Prepare to start Routine "Task3" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('Task3.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_23
        #设备上的rt有问题，现在改用计时开始的时间戳和计时结束的时间戳作差，若大于10000则超时
        countBegin=int(datetime.now().timestamp()*1000)
        #计时开始的时间戳
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        server_socket.sendall((str(stopwatchappears)).encode('utf-8')+ b'\n')
        
        key_resp_22.keys = []
        key_resp_22.rt = []
        _key_resp_22_allKeys = []
        # keep track of which components have finished
        Task3Components = [image_3, show_time, key_resp_22]
        for thisComponent in Task3Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Task3" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 10.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_3* updates
            
            # if image_3 is starting this frame...
            if image_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_3.frameNStart = frameN  # exact frame index
                image_3.tStart = t  # local t and not account for scr refresh
                image_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_3, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_3.started')
                # update status
                image_3.status = STARTED
                image_3.setAutoDraw(True)
            
            # if image_3 is active this frame...
            if image_3.status == STARTED:
                # update params
                pass
            
            # if image_3 is stopping this frame...
            if image_3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_3.tStartRefresh + 10.0-frameTolerance:
                    # keep track of stop time/frame for later
                    image_3.tStop = t  # not accounting for scr refresh
                    image_3.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_3.stopped')
                    # update status
                    image_3.status = FINISHED
                    image_3.setAutoDraw(False)
            
            # *show_time* updates
            
            # if show_time is starting this frame...
            if show_time.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                show_time.frameNStart = frameN  # exact frame index
                show_time.tStart = t  # local t and not account for scr refresh
                show_time.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(show_time, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'show_time.started')
                # update status
                show_time.status = STARTED
                show_time.setAutoDraw(True)
            
            # if show_time is active this frame...
            if show_time.status == STARTED:
                # update params
                show_time.setText(round(t,3), log=False)
            
            # if show_time is stopping this frame...
            if show_time.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > show_time.tStartRefresh + 10.0-frameTolerance:
                    # keep track of stop time/frame for later
                    show_time.tStop = t  # not accounting for scr refresh
                    show_time.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'show_time.stopped')
                    # update status
                    show_time.status = FINISHED
                    show_time.setAutoDraw(False)
            
            # *key_resp_22* updates
            waitOnFlip = False
            
            # if key_resp_22 is starting this frame...
            if key_resp_22.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_22.frameNStart = frameN  # exact frame index
                key_resp_22.tStart = t  # local t and not account for scr refresh
                key_resp_22.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_22, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_22.started')
                # update status
                key_resp_22.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_22.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_22.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_resp_22 is stopping this frame...
            if key_resp_22.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_resp_22.tStartRefresh + 10-frameTolerance:
                    # keep track of stop time/frame for later
                    key_resp_22.tStop = t  # not accounting for scr refresh
                    key_resp_22.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_22.stopped')
                    # update status
                    key_resp_22.status = FINISHED
                    key_resp_22.status = FINISHED
            if key_resp_22.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_22.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_22_allKeys.extend(theseKeys)
                if len(_key_resp_22_allKeys):
                    key_resp_22.keys = _key_resp_22_allKeys[-1].name  # just the last key pressed
                    key_resp_22.rt = _key_resp_22_allKeys[-1].rt
                    key_resp_22.duration = _key_resp_22_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Task3Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Task3" ---
        for thisComponent in Task3Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('Task3.stopped', globalClock.getTime())
        # Run 'End Routine' code from code_23
        #计时长度，若大于100000则超时
        countTime=int(datetime.now().timestamp()*1000)-countBegin
        # check responses
        if key_resp_22.keys in ['', [], None]:  # No response was made
            key_resp_22.keys = None
        trials_3.addData('key_resp_22.keys',key_resp_22.keys)
        if key_resp_22.keys != None:  # we had a response
            trials_3.addData('key_resp_22.rt', key_resp_22.rt)
            trials_3.addData('key_resp_22.duration', key_resp_22.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-10.000000)
        
        # --- Prepare to start Routine "xianshi" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('xianshi.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_2
        datastamp=int(datetime.now().timestamp()*1000)-timebegin
        if countTime<10000:
            feedback = "反应时间为：{:.3f}s".format(float(countTime)/1000)
            server_socket.sendall((str(correctTask3)).encode('utf-8')+ b'\n')
        else:
            feedback = "这个秒表运行结束了"
            server_socket.sendall((str(overrun)).encode('utf-8')+ b'\n')
        text_96.setText(feedback)
        # keep track of which components have finished
        xianshiComponents = [text_96]
        for thisComponent in xianshiComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "xianshi" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 1.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_96* updates
            
            # if text_96 is starting this frame...
            if text_96.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_96.frameNStart = frameN  # exact frame index
                text_96.tStart = t  # local t and not account for scr refresh
                text_96.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_96, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_96.started')
                # update status
                text_96.status = STARTED
                text_96.setAutoDraw(True)
            
            # if text_96 is active this frame...
            if text_96.status == STARTED:
                # update params
                pass
            
            # if text_96 is stopping this frame...
            if text_96.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_96.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    text_96.tStop = t  # not accounting for scr refresh
                    text_96.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_96.stopped')
                    # update status
                    text_96.status = FINISHED
                    text_96.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in xianshiComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "xianshi" ---
        for thisComponent in xianshiComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('xianshi.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-1.000000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 80.0 repeats of 'trials_3'
    
    
    # --- Prepare to start Routine "Goodbye" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('Goodbye.started', globalClock.getTime())
    key_resp_5.keys = []
    key_resp_5.rt = []
    _key_resp_5_allKeys = []
    # keep track of which components have finished
    GoodbyeComponents = [text_14, key_resp_5]
    for thisComponent in GoodbyeComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Goodbye" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_14* updates
        
        # if text_14 is starting this frame...
        if text_14.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_14.frameNStart = frameN  # exact frame index
            text_14.tStart = t  # local t and not account for scr refresh
            text_14.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_14, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_14.started')
            # update status
            text_14.status = STARTED
            text_14.setAutoDraw(True)
        
        # if text_14 is active this frame...
        if text_14.status == STARTED:
            # update params
            pass
        
        # *key_resp_5* updates
        waitOnFlip = False
        
        # if key_resp_5 is starting this frame...
        if key_resp_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_5.frameNStart = frameN  # exact frame index
            key_resp_5.tStart = t  # local t and not account for scr refresh
            key_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_5.started')
            # update status
            key_resp_5.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_5.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_5.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_5.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_5_allKeys.extend(theseKeys)
            if len(_key_resp_5_allKeys):
                key_resp_5.keys = _key_resp_5_allKeys[-1].name  # just the last key pressed
                key_resp_5.rt = _key_resp_5_allKeys[-1].rt
                key_resp_5.duration = _key_resp_5_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in GoodbyeComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Goodbye" ---
    for thisComponent in GoodbyeComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Goodbye.stopped', globalClock.getTime())
    # check responses
    if key_resp_5.keys in ['', [], None]:  # No response was made
        key_resp_5.keys = None
    thisExp.addData('key_resp_5.keys',key_resp_5.keys)
    if key_resp_5.keys != None:  # we had a response
        thisExp.addData('key_resp_5.rt', key_resp_5.rt)
        thisExp.addData('key_resp_5.duration', key_resp_5.duration)
    thisExp.nextEntry()
    # the Routine "Goodbye" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    # Run 'End Experiment' code from code_14
    server_socket.sendall((str(endOfTheParadigm)).encode('utf-8')+ b'\n')
    
    
    # mark experiment as finished
    endExperiment(thisExp, win=win, inputs=inputs)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experfiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, inputs=None, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    inputs : dict
        Dictionary of input devices by name.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # shut down eyetracker, if there is one
    if inputs is not None:
        if 'eyetracker' in inputs and inputs['eyetracker'] is not None:
            inputs['eyetracker'].setConnectionState(False)
    logging.flush()


def quit(thisExp, win=None, inputs=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    inputs : dict
        Dictionary of input devices by name.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    if inputs is not None:
        if 'eyetracker' in inputs and inputs['eyetracker'] is not None:
            inputs['eyetracker'].setConnectionState(False)
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    # expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    inputs = setupInputs(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win, 
        inputs=inputs
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win, inputs=inputs)
